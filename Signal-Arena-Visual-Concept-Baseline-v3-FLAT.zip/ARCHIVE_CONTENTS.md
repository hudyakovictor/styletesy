# Archive contents verification

Required root paths:

- `00_READ_ME_FIRST.txt`
- `AGENT_START_HERE.md`
- `FINAL_AGENT_PROMPT.md`
- `docs/`
- `content-library/`
- `src/design-system/`
- `src/concept/`
- `public/assets/`
- `package.json`

Run after extraction:

```bash
test -f AGENT_START_HERE.md
test -f FINAL_AGENT_PROMPT.md
test -d docs
test -f content-library/mock-data.json
test -f content-library/screen-contract.json
test -f content-library/included-assets.json
test -f content-library/canonical-asset-manifest.json
test -d src/design-system
```

If any check fails, the wrong file or wrong directory is being inspected.
