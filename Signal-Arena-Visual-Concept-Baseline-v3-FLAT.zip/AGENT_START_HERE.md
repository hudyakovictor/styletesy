# Agent start here

## Archive extraction gate

Work in a NEW EMPTY DIRECTORY. Detect the attachment as ZIP even if it is named `.pdf`, extract it there, and `cd` into the extracted directory. Before any project audit, verify that the current directory contains all of these paths:

```text
AGENT_START_HERE.md
docs/
content-library/mock-data.json
content-library/screen-contract.json
content-library/included-assets.json
content-library/canonical-asset-manifest.json
src/design-system/
```

If they are not visible, recursively search for `AGENT_START_HERE.md` and enter its parent directory. Do not inspect an unrelated pre-existing scaffold and do not report these files missing until this extraction gate has been completed. If the archive itself cannot be accessed or extracted, stop and report an attachment/extraction failure instead of generating a replacement project.

This archive is the identical baseline used to compare several agents.

1. Read `docs/FINAL_AGENT_PROMPT.md` in full.
2. Read `docs/PRODUCT_VISUAL_BRIEF.md` and `docs/SCREEN_CONTRACT.md`.
3. Inspect `content-library/mock-data.json`.
4. Inspect the reusable UI in `src/design-system/`.
5. Do not edit `src/design-system/**`.
6. Put all product-screen work in `src/concept/**`.
7. Do not implement the chart, terminal, game engine or backend.
8. Before editing, report your plan and intended files.

The current `src/App.tsx` is a component showcase, not a product direction. The primary menu contract is fixed to Hub, Academy, Arena, Shop and Tournaments; Arena owns the whole practice flow. Replace it with routing into your concept while preserving the UI core.
