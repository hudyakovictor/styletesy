# FINAL BUILDER PROMPT — Signal Arena visual concept benchmark

## Archive extraction gate

Work in a NEW EMPTY DIRECTORY. Detect the attachment as ZIP even if it is named `.pdf`, extract it there, and `cd` into the extracted directory. Before any project audit, verify that the current directory contains all of these paths:

```text
AGENT_START_HERE.md
docs/
content-library/mock-data.json
content-library/screen-contract.json
content-library/included-assets.json
content-library/canonical-asset-manifest.json
src/design-system/
```

If they are not visible, recursively search for `AGENT_START_HERE.md` and enter its parent directory. Do not inspect an unrelated pre-existing scaffold and do not report these files missing until this extraction gate has been completed. If the archive itself cannot be accessed or extracted, stop and report an attachment/extraction failure instead of generating a replacement project.

Приложенный файл может иметь расширение `.pdf` только из-за ограничения загрузки. Фактически это ZIP-архив. Не пытайся читать его как PDF: определи формат, скопируй или переименуй файл в `.zip`, распакуй и работай с содержимым.

## Роль

Ты — senior product designer и frontend engineer. Твоя задача — создать цельный, красивый, кликабельный визуальный концепт Telegram Mini App **Signal Arena** на статичных mock-данных.

Это конкурс визуальных направлений между несколькими агентами. Все получают один baseline. Не пытайся строить production-приложение, backend или настоящую игровую механику.

## Обязательное начало

До любых изменений:

1. Покажи структуру распакованного проекта.
2. Прочитай `AGENT_START_HERE.md`.
3. Прочитай все документы в `docs/`.
4. Изучи `content-library/mock-data.json` и `screen-contract.json`.
5. Изучи `src/design-system/`.
6. Кратко опиши выбранную визуальную концепцию.
7. Перечисли все создаваемые и изменяемые файлы.
8. Подтверди, что `src/design-system/**` останется неизменным.

Не начинай реализацию до завершения этого короткого аудита.

## Цель

Собрать единый визуальный прототип, по которому владелец сможет оценить:

- как Signal Arena выглядит как законченный продукт;
- насколько согласованы его разделы;
- подходит ли интерфейс для вертикального Telegram Mini App;
- насколько хорошо дизайн передаёт стратегию, анализ, signal vs noise и process-first обучение;
- какое визуальное направление следует зафиксировать перед реализацией core loop.

## Технологии

Используй существующий baseline:

- React;
- TypeScript;
- Vite;
- локальные mock-данные;
- предоставленные assets;
- предоставленную дизайн-систему.

Не меняй стек без объективной необходимости. Не подключай внешние UI kits и не заменяй существующую дизайн-систему Tailwind, Material UI, shadcn или другой библиотекой.

## Граница дизайн-системы

`src/design-system/**` является read-only.

Разрешено:

- импортировать и комбинировать существующие компоненты;
- создавать screen-level layouts в `src/concept/**`;
- создавать локальные композиционные компоненты, специфичные для концепта;
- добавлять mock navigation и демонстрационные состояния;
- добавлять screen-level CSS, использующий существующие tokens.

Запрещено:

- менять токены;
- переписывать существующие компоненты;
- создавать вторую дизайн-систему;
- добавлять универсальный page generator;
- создавать page kits, presets или Bento Composer;
- прятать изменения дизайн-системы под видом исправления экрана.

Если компонента не хватает, используй композицию существующих primitives и зафиксируй недостаток в `docs/DESIGN_SYSTEM_GAPS.md`. Core самостоятельно не меняй.

## Информационная архитектура — не изменять

В основном меню должно быть ровно пять root-разделов:

1. Hub.
2. Academy.
3. Arena.
4. Shop.
5. Tournaments.

Не добавляй шестой пункт и не заменяй эти разделы. Profile, Collection, Decision Workspace, Reveal, Debrief, Rematch и Settings не являются пунктами основного меню.

### Arena — полный практический режим

Arena владеет всем практическим сценарием:

```text
Arena home / mode selection
→ Scenario Brief
→ Decision Workspace
→ Decision Seal
→ Historical Reveal
→ Score
→ Debrief
→ Rematch
→ return to Arena
```

Decision Workspace, Reveal, Score, Debrief и Rematch нужно спроектировать как вложенные состояния Arena, а не как самостоятельные root-разделы. Пользователь входит в них из Arena и после завершения возвращается в Arena.

### Вторичные поверхности

- Entry / Calibration показывается до основного application shell.
- Profile открывается через avatar/account control в Top Bar, а не через основное меню.
- Settings открывается через единую кнопку-шестерёнку в Top Bar.
- Notifications открывается через bell в Top Bar.
- Collection / Vault размещается внутри Academy как вложенный каталог карт и Entities. Допустимы вторичные ссылки из Profile или Arena loadout, но отдельного пункта основного меню быть не должно.

### Что нужно визуально показать

Пять основных разделов:

- Hub;
- Academy, включая вложенный Collection/Vault;
- Arena home / mode selection;
- Shop — статичный концепт;
- Tournaments — staged/coming-soon концепт.

Внутренний Arena flow:

- Scenario Brief;
- Decision Workspace;
- Historical Reveal + Score + Debrief;
- Rematch.

Вторичные состояния:

- Entry / Calibration;
- Profile;
- Settings.

Все состояния должны быть доступны через правильного родителя без ручного изменения URL и без превращения их в дополнительные пункты основного меню.

## Decision Workspace

Вся сложная область терминала, графика и механики намеренно исключена.

Используй `MarketWorkspaceSlot` как нейтральный зарезервированный блок. Можно адаптировать его внешний размер на уровне layout, но нельзя наполнять его псевдографиком.

Внутри этого блока запрещено рисовать:

- свечи;
- индикаторы;
- order book;
- торговую форму;
- линии entry/stop/target;
- правдоподобные рыночные данные;
- псевдофункциональную механику.

Нужно спроектировать всё окружение блока: hierarchy, cards/evidence, hypothesis, confidence, decisions, seal CTA, responsive composition. Сам слот остаётся заглушкой для будущей изолированной задачи.

## Mock data и assets

Используй `content-library/mock-data.json` как единый источник демонстрационных данных.

Не придумывай несовместимые значения для разных экранов. Уровень, Energy, Stars, Coins, текущий урок и Process Score должны оставаться согласованными.

Для runtime используй только assets, перечисленные в `included-assets.json`:

- 8 Skill Cards;
- 5 Entities;
- UI icons и logo.

`canonical-asset-manifest.json` дан только как справочник полной библиотеки. Не создавай галерею всех 40+40 элементов и не подключай отсутствующие изображения.

Имена Entities не переводить и не переименовывать.

## Визуальное направление

Интерфейс должен передавать:

- стратегическое напряжение;
- forensic analysis;
- signal vs noise;
- дисциплину решения;
- ощущение игры без fantasy combat;
- крипторынок без имитации биржевого терминала.

Не превращай продукт в:

- Binance clone;
- обычную SaaS dashboard;
- cyberpunk-перегрузку;
- карточный battler;
- казино;
- коллекцию несвязанных красивых экранов.

Все экраны должны ощущаться одной системой. Секционные акценты допустимы, отдельные UI-библиотеки для разделов — нет.

## Текстовый голос

Пиши коротко и конкретно. Допустима смесь сухого протокола и панк-таблоидной криптосатиры, если она объясняет мысль.

Карты — аналитические инструменты, не магия. Entities — наблюдаемые искажения решения, не монстры, которых атакуют. Хороший outcome не доказывает хороший процесс.

## Разрешённая интерактивность

Только демонстрационная:

- навигация между экранами;
- tabs и filters;
- modal, drawer или bottom sheet;
- выбор mock-карты;
- переключение mock-decision;
- заранее заданный переход `Seal → Reveal`;
- раскрытие выбранного элемента коллекции;
- desktop/mobile responsive behavior.

Данные остаются статичными. Ничего не нужно рассчитывать или сохранять.

## Запрещённый scope

Не добавляй:

- backend;
- API server;
- authentication;
- Telegram SDK;
- database;
- persistence;
- real historical providers;
- scoring engine;
- game state machine;
- Phaser;
- WebSocket;
- настоящую экономику;
- payment/checkout flow;
- Telegram Stars integration;
- tournament engine;
- CRM;
- blockchain или wallet;
- analytics infrastructure.

Shop и Tournaments должны выглядеть как продуктовые концепты, но не иметь рабочей коммерции или соревновательной логики.

## Responsive и accessibility

Обязательно:

- mobile-first;
- качественный вид при 390×844;
- проверка узкой ширины 360 px;
- desktop 1440 px;
- отсутствие horizontal overflow;
- touch targets минимум 44×44 px;
- видимый keyboard focus;
- семантические headings, buttons и navigation;
- достаточный контраст;
- поддержка `prefers-reduced-motion`;
- отсутствие критической информации, передаваемой только цветом;
- отсутствие текста, который становится нечитаемым на мобильном.

## Motion

Motion используется только для объяснения изменения состояния.

Ориентиры: 60 / 120 / 180 / 240 / 400 ms, максимум 600 ms для редкого reveal. Не используй постоянные пульсации, casino effects, coin showers, shake как наказание или анимации, задерживающие доступ к действию.

## Deliverables

Итог должен содержать:

- рабочий исходный проект;
- пять root-разделов и все обязательные вложенные состояния;
- `docs/DESIGN_DECISIONS.md`;
- `docs/DESIGN_SYSTEM_GAPS.md`;
- `VERIFICATION.md`;
- screenshots пяти root-разделов, Arena flow и вторичных поверхностей на 390 px;
- минимум один desktop overview screenshot;
- полный ZIP без `node_modules`, cache, coverage и временных файлов.

Имена screenshots:

```text
screenshots/00-entry-calibration-mobile.png
screenshots/01-hub-mobile.png
screenshots/02-academy-mobile.png
screenshots/02a-academy-collection-mobile.png
screenshots/03-arena-home-mobile.png
screenshots/03a-arena-scenario-brief-mobile.png
screenshots/03b-arena-decision-workspace-mobile.png
screenshots/03c-arena-reveal-score-debrief-mobile.png
screenshots/03d-arena-rematch-mobile.png
screenshots/04-shop-mobile.png
screenshots/05-tournaments-mobile.png
screenshots/secondary-profile-mobile.png
screenshots/secondary-settings-mobile.png
screenshots/desktop-overview.png
```

Нумерация отражает иерархию: `03a–03d` — состояния внутри Arena, а не отдельные основные разделы.

## Проверки перед сдачей

Фактически выполни и зафиксируй результаты:

1. Установка зависимостей.
2. TypeScript typecheck.
3. Production build.
4. Открытие пяти root-разделов через основное меню.
5. Прохождение вложенного Arena flow до Rematch.
6. Открытие Profile через avatar и Settings через gear.
7. Проверка 390×844.
8. Проверка 360 px.
9. Проверка desktop 1440 px.
10. Проверка console errors.
11. Проверка horizontal overflow.
12. Проверка keyboard navigation и focus.
13. Проверка reduced motion.
14. Подтверждение, что `src/design-system/**` не изменён.
15. Подтверждение, что основное меню содержит ровно пять канонических разделов.

Не заявляй PASS, если проверка не запускалась. В таком случае пиши `NOT TESTED` и объясняй причину.

## Формат финального ответа

В конце сообщи:

1. Краткую концепцию.
2. Какие экраны реализованы.
3. Какие файлы изменены.
4. Какие проверки прошли.
5. Какие проверки не удалось выполнить.
6. Какие design-system gaps обнаружены.
7. Известные ограничения.
8. Имя и размер итогового архива.

После этого верни ZIP. Если система не принимает ZIP, измени только расширение итогового ZIP на `.pdf` и явно укажи, что это ZIP-контейнер, а не настоящий PDF.
