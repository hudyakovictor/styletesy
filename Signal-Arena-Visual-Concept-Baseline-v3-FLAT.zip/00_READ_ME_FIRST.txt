SIGNAL ARENA VISUAL CONCEPT BASELINE — FLAT ARCHIVE

This archive is self-contained. After extraction, the CURRENT DIRECTORY must contain:

AGENT_START_HERE.md
docs/
content-library/
src/design-system/
public/assets/
package.json

Do not inspect or modify an existing Arena scaffold before extracting this archive into a NEW EMPTY DIRECTORY and changing into it.

If these paths are not visible, run a recursive search for AGENT_START_HERE.md. Do not claim they are missing until the archive has been detected as ZIP, extracted, and the correct directory has been entered.

The .pdf upload is a ZIP byte-for-byte with only its extension changed.
