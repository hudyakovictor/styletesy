# Agent start here

This archive is the identical baseline used to compare several agents.

1. Read `docs/FINAL_AGENT_PROMPT.md` in full.
2. Read `docs/PRODUCT_VISUAL_BRIEF.md` and `docs/SCREEN_CONTRACT.md`.
3. Inspect `content-library/mock-data.json`.
4. Inspect the reusable UI in `src/design-system/`.
5. Do not edit `src/design-system/**`.
6. Put all product-screen work in `src/concept/**`.
7. Do not implement the chart, terminal, game engine or backend.
8. Before editing, report your plan and intended files.

The current `src/App.tsx` is a component showcase, not a product direction. The primary menu contract is fixed to Hub, Academy, Arena, Shop and Tournaments; Arena owns the whole practice flow. Replace it with routing into your concept while preserving the UI core.
