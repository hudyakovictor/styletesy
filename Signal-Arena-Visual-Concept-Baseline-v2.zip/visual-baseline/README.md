# Signal Arena Visual Concept Baseline

Autonomous baseline for comparing visual concepts from multiple agents.

Start with `AGENT_START_HERE.md`, then use `docs/FINAL_AGENT_PROMPT.md` without rewriting it between sessions.

## Commands

```bash
npm install
npm run dev
npm run typecheck
npm run build
```

## Boundaries

- `src/design-system/**` is read-only.
- Product concepts belong in `src/concept/**`.
- No backend, API, auth, database, scoring engine, market chart or trading terminal.
- The market/mechanics area remains a neutral reserved slot.
