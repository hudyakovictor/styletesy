# Visual review rubric — 100 points

| Criterion | Weight |
|---|---:|
| Product coherence and correct five-section hierarchy | 20 |
| Mobile hierarchy and usability at 390 px | 20 |
| Faithful use of the supplied design system | 15 |
| Information hierarchy and readable density | 15 |
| Decision Workspace composition around the reserved slot | 10 |
| Brand character without terminal/dashboard imitation | 10 |
| Accessibility, focus and reduced motion | 5 |
| Scope discipline and honest verification | 5 |

Automatic rejection conditions:

- future/chart mechanics implemented instead of the reserved slot;
- core design-system files silently modified;
- backend, auth, database or payment integration added;
- primary navigation contains anything other than Hub, Academy, Arena, Shop and Tournaments;
- Arena flow is incorrectly presented as separate root sections;
- Collection, Profile or Settings appears as a primary menu item;
- missing required states;
- horizontal overflow at 390 px;
- submission cannot build after a normal dependency install;
- screenshots or verification claims are fabricated.
