# Information architecture and required visual states

## Five primary sections — fixed

The product has exactly five root sections in its primary menu:

1. **Hub**
2. **Academy**
3. **Arena**
4. **Shop**
5. **Tournaments**

Do not add Profile, Collection, Decision Workspace, Reveal, Debrief, Rematch or Settings to the primary menu.

## Arena is the practice section

Arena is not merely a separate lobby screen. It owns the complete practical scenario flow:

```text
Arena home / mode selection
→ Scenario Brief
→ Decision Workspace
→ Decision Seal
→ Historical Reveal
→ Score
→ Debrief
→ Rematch
→ return to Arena
```

Decision Workspace, Reveal, Score, Debrief and Rematch are nested Arena route states. They are required visual frames, but they are not root navigation sections.

## Secondary surfaces

- **Entry / Calibration** appears before the primary application shell.
- **Profile** opens from the avatar/account control in the Top Bar and is not a menu item.
- **Settings** opens from the single gear button in the Top Bar and is not a menu item.
- **Notifications** opens from the bell in the Top Bar.
- **Collection / Vault** is not a standalone primary section. Show cards and Entities as a nested destination or panel inside Academy, with optional cross-links from Profile or Arena loadout.

## Required visual deliverables

### Primary sections

- Hub
- Academy, including its nested Collection/Vault concept
- Arena home / mode selection
- Shop — static concept only
- Tournaments — staged/coming-soon concept only

### Arena internal flow

- Scenario Brief
- Decision Workspace with the reserved Market Workspace Slot
- Historical Reveal + Score + Debrief as one coherent result sequence/surface
- Rematch state

### Secondary surfaces

- Entry / Calibration
- Profile
- Settings

Every state must be reachable through the correct parent flow without pretending it is another root section.

## Market workspace boundary

The chart, terminal and scenario mechanics are excluded. Use `MarketWorkspaceSlot` as a neutral reserved rectangle. Do not draw fake candles, indicators, order forms or pseudo-functional trading controls inside it.
