# Signal Arena — visual concept brief

Signal Arena is a vertical Telegram Mini App for training the quality of market decisions on historical crypto scenarios. It is not a broker, trading terminal, investment adviser, casino or fantasy card battler.

## Brand

- The central image is crossed bullish/bearish candlesticks on an arena shield.
- The contest is between decisions, evidence and discipline — not literal bulls and bears.
- Desired feeling: strategic tension, forensic analysis, signal vs noise, competitive game clarity.
- Avoid Binance clones, admin dashboards, cyberpunk overload, slot-machine effects and decorative financial charts.

## Product doctrine

The learning loop is:

`Fact → Interpretation → Hypothesis → Plan → Invalidation → Action → Debrief`

Cards are analytical tools, not spells. Entities represent recurring cognitive or process distortions, not enemies fought on a battlefield. Profit does not prove decision quality.

## Voice

Punk-tabloid crypto satire plus a dry instructional protocol. Sentences are short, clear to a novice and specific. Humor must clarify the lesson.

Example:

> НОВОСТЬ НЕ ЯВЛЯЕТСЯ СИГНАЛОМ.  
> Сигналом является реакция рынка.  
> Заголовок просто громко просит твои деньги.

## Shell

Canonical primary sections are fixed: **Hub, Academy, Arena, Shop and Tournaments**. Arena owns the whole practical scenario flow, including Decision Workspace, Reveal, Score, Debrief and Rematch. Collection/Vault is nested inside Academy rather than occupying a root menu item. Profile opens from the account/avatar control; Settings opens from the single gear button in the Top Bar. For this visual benchmark all product data is static.

## Motion

Motion explains state changes only. Canonical durations: 60, 120, 180, 240, 400 and maximum 600 ms. Reduced-motion support is mandatory. No coin showers, loot-box reveals or constant decorative pulsing.
