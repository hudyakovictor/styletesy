import { AppRoot } from "./concept/AppRoot";

export default function App() {
  return (
    <div className="sa-grid-bg flex h-full justify-center">
      {/* On desktop, present the Mini App as a centered device frame. */}
      <div className="relative flex h-full w-full max-w-[440px] flex-col overflow-hidden border-x border-[var(--sa-line)] bg-[var(--sa-bg-0)] shadow-[0_0_80px_-20px_rgba(0,0,0,0.9)] md:my-0">
        <AppRoot />
      </div>
    </div>
  );
}
