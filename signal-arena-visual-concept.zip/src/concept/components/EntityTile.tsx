export interface EntityData {
  id: string;
  name: string;
  distortion: string;
  color: string;
  observed: string;
  counter: string;
  tell: string;
}

export function EntityGlyph({ color, size = 44 }: { color: string; size?: number }) {
  return (
    <div
      className="relative flex items-center justify-center rounded-[var(--sa-r-md)] border"
      style={{
        width: size,
        height: size,
        borderColor: color,
        background: `color-mix(in srgb, ${color} 12%, var(--sa-bg-2))`,
      }}
      aria-hidden
    >
      <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.6">
        <path d="M12 3l7 4v6c0 4-3 6-7 8-4-2-7-4-7-8V7l7-4z" strokeLinejoin="round" />
        <path d="M9 12l2 2 4-4" strokeLinecap="round" strokeLinejoin="round" opacity="0.6" />
      </svg>
    </div>
  );
}

export function EntityTile({ entity, onClick }: { entity: EntityData; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-label={`${entity.name} — ${entity.distortion}`}
      className="flex w-full items-center gap-3 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-3 text-left transition-colors duration-[var(--sa-t-base)] hover:border-[var(--sa-line)]/70"
    >
      <EntityGlyph color={entity.color} />
      <div className="min-w-0 flex-1">
        <div className="sa-display text-[14px] font-bold tracking-wide text-[var(--sa-text-hi)]">
          {entity.name}
        </div>
        <div className="sa-mono text-[10px] uppercase tracking-wide" style={{ color: entity.color }}>
          {entity.distortion}
        </div>
        <p className="mt-1 truncate text-[12px] text-[var(--sa-text-dim)]">{entity.observed}</p>
      </div>
    </button>
  );
}
