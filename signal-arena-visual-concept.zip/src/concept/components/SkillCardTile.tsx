import { Icon } from "../../design-system";
import { rarityColor } from "../data";

export interface SkillCardData {
  id: string;
  name: string;
  rarity: string;
  type: string;
  color: string;
  short: string;
  body?: string;
}

export function SkillCardTile({
  card,
  onClick,
  compact,
}: {
  card: SkillCardData;
  onClick?: () => void;
  compact?: boolean;
}) {
  const rc = rarityColor[card.rarity] ?? card.color;
  return (
    <button
      onClick={onClick}
      aria-label={`${card.name} — ${card.rarity} ${card.type}`}
      className="group relative flex w-full flex-col overflow-hidden rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-3 text-left transition-[transform,border-color] duration-[var(--sa-t-base)] hover:-translate-y-0.5"
      style={{ borderTopColor: rc, borderTopWidth: 2 }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-15 blur-xl"
        style={{ background: rc }}
      />
      <div className="mb-2 flex items-center justify-between">
        <span
          className="sa-mono text-[9px] uppercase tracking-[0.18em]"
          style={{ color: rc }}
        >
          {card.rarity}
        </span>
        <span className="text-[var(--sa-text-dim)] [&_svg]:h-4 [&_svg]:w-4">
          <Icon.layers />
        </span>
      </div>
      <div className="sa-display text-[15px] font-semibold leading-tight text-[var(--sa-text-hi)]">
        {card.name}
      </div>
      <div className="sa-mono mt-0.5 text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
        {card.type}
      </div>
      {!compact && (
        <p className="mt-2 text-[12px] leading-snug text-[var(--sa-text)]">{card.short}</p>
      )}
    </button>
  );
}
