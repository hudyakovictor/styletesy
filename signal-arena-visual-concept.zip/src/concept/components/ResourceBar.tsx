import { Icon } from "../../design-system";
import { player } from "../data";

export function ResourceBar() {
  return (
    <div className="flex items-center gap-1.5">
      <Chip icon={<Icon.bolt />} value={`${player.energy}/${player.energyMax}`} color="var(--sa-signal)" label="Energy" />
      <Chip icon={<Icon.star />} value={player.stars} color="var(--sa-noise)" label="Stars" />
      <Chip icon={<Icon.coin />} value={player.coins} color="var(--sa-accent-hub)" label="Coins" />
    </div>
  );
}

function Chip({
  icon,
  value,
  color,
  label,
}: {
  icon: React.ReactNode;
  value: React.ReactNode;
  color: string;
  label: string;
}) {
  return (
    <div className="flex items-center gap-1 rounded-full border border-[var(--sa-line)] bg-[var(--sa-bg-2)] px-2 py-1">
      <span className="[&_svg]:h-3.5 [&_svg]:w-3.5" style={{ color }} aria-hidden>
        {icon}
      </span>
      <span className="sa-mono text-[12px] font-semibold text-[var(--sa-text-hi)]">{value}</span>
      <span className="sr-only">{label}</span>
    </div>
  );
}
