import { createContext, useContext } from "react";
import type { RootSection } from "../design-system";

/* Arena internal states are NESTED within Arena, not root sections. */
export type ArenaState = "home" | "brief" | "workspace" | "reveal" | "rematch";

export type Overlay = "profile" | "settings" | "notifications" | null;

export interface Nav {
  section: RootSection;
  arena: ArenaState;
  overlay: Overlay;
  booted: boolean;
  goSection: (s: RootSection) => void;
  goArena: (s: ArenaState) => void;
  openOverlay: (o: Overlay) => void;
  boot: () => void;
  goAcademyCollection: (open: boolean) => void;
  academyCollectionOpen: boolean;
}

export const NavContext = createContext<Nav | null>(null);

export function useNav(): Nav {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error("useNav must be used within NavContext");
  return ctx;
}
