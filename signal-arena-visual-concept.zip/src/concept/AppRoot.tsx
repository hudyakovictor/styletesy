import { useMemo, useState } from "react";
import { TopBar, BottomNav } from "../design-system";
import type { RootSection } from "../design-system";
import { NavContext } from "./router";
import type { ArenaState, Overlay } from "./router";
import { player } from "./data";
import { ResourceBar } from "./components/ResourceBar";

import { Entry } from "./screens/Entry";
import { Hub } from "./screens/Hub";
import { Academy } from "./screens/Academy";
import { ArenaHome } from "./screens/ArenaHome";
import { ScenarioBrief } from "./screens/ScenarioBrief";
import { DecisionWorkspace } from "./screens/DecisionWorkspace";
import { RevealScoreDebrief } from "./screens/RevealScoreDebrief";
import { Rematch } from "./screens/Rematch";
import { Shop } from "./screens/Shop";
import { Tournaments } from "./screens/Tournaments";
import { Profile } from "./screens/Profile";
import { Settings } from "./screens/Settings";
import { Notifications } from "./screens/Notifications";

const sectionMeta: Record<RootSection, { title: string; subtitle: string }> = {
  hub: { title: "Hub", subtitle: "Command deck" },
  academy: { title: "Academy", subtitle: "Learn · Vault" },
  arena: { title: "Arena", subtitle: "Practice loop" },
  shop: { title: "Shop", subtitle: "Cosmetic concept" },
  tournament: { title: "Tournaments", subtitle: "Staged" },
};

const arenaMeta: Record<ArenaState, { title: string; subtitle: string; back: boolean }> = {
  home: { title: "Arena", subtitle: "Practice loop", back: false },
  brief: { title: "Scenario Brief", subtitle: "Arena · step 1", back: true },
  workspace: { title: "Decision Workspace", subtitle: "Arena · step 2", back: true },
  reveal: { title: "Reveal · Score · Debrief", subtitle: "Arena · step 3", back: true },
  rematch: { title: "Rematch", subtitle: "Arena · loop end", back: true },
};

export function AppRoot() {
  const [booted, setBooted] = useState(false);
  const [section, setSection] = useState<RootSection>("hub");
  const [arena, setArena] = useState<ArenaState>("home");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [academyCollectionOpen, setAcademyCollectionOpen] = useState(false);

  const nav = useMemo(
    () => ({
      section,
      arena,
      overlay,
      booted,
      academyCollectionOpen,
      goSection: (s: RootSection) => {
        setSection(s);
        if (s === "arena") setArena("home");
        if (s !== "academy") setAcademyCollectionOpen(false);
      },
      goArena: (s: ArenaState) => {
        setSection("arena");
        setArena(s);
      },
      openOverlay: (o: Overlay) => setOverlay(o),
      boot: () => setBooted(true),
      goAcademyCollection: (open: boolean) => {
        setSection("academy");
        setAcademyCollectionOpen(open);
      },
    }),
    [section, arena, overlay, booted, academyCollectionOpen]
  );

  if (!booted) {
    return (
      <div className="flex h-full flex-col">
        <NavContext.Provider value={nav}>
          <Entry onEnter={() => setBooted(true)} />
        </NavContext.Provider>
      </div>
    );
  }

  const isArenaSub = section === "arena" && arena !== "home";
  const arenaM = arenaMeta[arena];
  const meta = sectionMeta[section];

  const topTitle = section === "arena" ? arenaM.title : meta.title;
  const topSubtitle = section === "arena" ? arenaM.subtitle : meta.subtitle;
  const showBack = section === "arena" ? arenaM.back : academyCollectionOpen && section === "academy";

  const onBack = () => {
    if (section === "arena") {
      if (arena === "brief") setArena("home");
      else if (arena === "workspace") setArena("brief");
      else if (arena === "reveal") setArena("workspace");
      else if (arena === "rematch") setArena("reveal");
    } else if (section === "academy" && academyCollectionOpen) {
      setAcademyCollectionOpen(false);
    }
  };

  return (
    <NavContext.Provider value={nav}>
      <div className="flex h-full flex-col bg-[var(--sa-bg-0)]">
        <TopBar
          title={topTitle}
          subtitle={academyCollectionOpen && section === "academy" ? "Academy · Vault" : topSubtitle}
          onBack={showBack ? onBack : undefined}
          right={
            !isArenaSub && !(section === "academy" && academyCollectionOpen) ? (
              <div className="hidden min-[380px]:block">
                <ResourceBar />
              </div>
            ) : undefined
          }
          onBell={() => setOverlay("notifications")}
          onSettings={() => setOverlay("settings")}
          onProfile={() => setOverlay("profile")}
          notifCount={2}
          avatar={player.avatar}
        />

        {section === "hub" && <Hub />}
        {section === "academy" && (
          <Academy collectionOpen={academyCollectionOpen} setCollectionOpen={setAcademyCollectionOpen} />
        )}
        {section === "arena" && arena === "home" && <ArenaHome />}
        {section === "arena" && arena === "brief" && <ScenarioBrief />}
        {section === "arena" && arena === "workspace" && <DecisionWorkspace />}
        {section === "arena" && arena === "reveal" && <RevealScoreDebrief />}
        {section === "arena" && arena === "rematch" && <Rematch />}
        {section === "shop" && <Shop />}
        {section === "tournament" && <Tournaments />}

        <BottomNav active={section} onChange={(s) => nav.goSection(s)} />
      </div>

      <Profile
        open={overlay === "profile"}
        onClose={() => setOverlay(null)}
        onOpenVault={() => {
          setOverlay(null);
          nav.goAcademyCollection(true);
        }}
      />
      <Settings open={overlay === "settings"} onClose={() => setOverlay(null)} />
      <Notifications open={overlay === "notifications"} onClose={() => setOverlay(null)} />
    </NavContext.Provider>
  );
}
