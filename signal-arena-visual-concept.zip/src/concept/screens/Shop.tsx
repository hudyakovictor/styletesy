import { ScreenShell, Card, CardBody, Button, Badge, Icon, SectionTitle } from "../../design-system";
import { data, rarityColor } from "../data";

export function Shop() {
  const shop = data.shop;
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-accent-shop)">
        <CardBody>
          <div className="flex items-center justify-between">
            <Badge tone="noise">Season pass</Badge>
            <span className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
              Concept
            </span>
          </div>
          <div className="sa-display mt-2 text-[20px] font-bold text-[var(--sa-text-hi)]">
            {shop.featured.name}
          </div>
          <p className="mt-1 text-[13px] leading-snug text-[var(--sa-text-dim)]">{shop.featured.desc}</p>
          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[var(--sa-noise)]">
              <span className="[&_svg]:h-5 [&_svg]:w-5"><Icon.star /></span>
              <span className="sa-mono text-[18px] font-bold text-[var(--sa-text-hi)]">
                {shop.featured.price}
              </span>
            </div>
            <Button variant="signal" size="md">Preview</Button>
          </div>
        </CardBody>
      </Card>

      {shop.sections.map((sec) => (
        <div key={sec.id} className="mt-5">
          <SectionTitle kicker="Cosmetic only">{sec.name}</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            {sec.items.map((it) => {
              const rc = rarityColor[it.rarity] ?? "var(--sa-line)";
              return (
                <Card key={it.id} interactive>
                  <div
                    className="flex h-20 items-center justify-center rounded-t-[var(--sa-r-lg)] border-b border-[var(--sa-line)]"
                    style={{ background: `linear-gradient(135deg, color-mix(in srgb, ${rc} 22%, var(--sa-bg-2)), var(--sa-bg-1))` }}
                  >
                    <span className="[&_svg]:h-7 [&_svg]:w-7" style={{ color: rc }}>
                      <Icon.layers />
                    </span>
                  </div>
                  <CardBody className="p-3">
                    <div className="sa-mono text-[9px] uppercase tracking-[0.16em]" style={{ color: rc }}>
                      {it.rarity}
                    </div>
                    <div className="text-[13px] font-medium text-[var(--sa-text-hi)]">{it.name}</div>
                    <div className="mt-2 flex items-center gap-1">
                      <span className="[&_svg]:h-3.5 [&_svg]:w-3.5" style={{ color: it.currency === "stars" ? "var(--sa-noise)" : "var(--sa-accent-hub)" }}>
                        {it.currency === "stars" ? <Icon.star /> : <Icon.coin />}
                      </span>
                      <span className="sa-mono text-[13px] font-semibold text-[var(--sa-text-hi)]">{it.price}</span>
                    </div>
                  </CardBody>
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      <div className="mt-6 rounded-[var(--sa-r-md)] border border-dashed border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-3 text-center">
        <p className="text-[11px] leading-snug text-[var(--sa-text-faint)]">{shop.disclaimer}</p>
      </div>
    </ScreenShell>
  );
}
