import { useState } from "react";
import { ScreenShell, Tabs, Badge, Sheet, Button } from "../../design-system";
import { skillCards, entities } from "../data";
import { SkillCardTile } from "../components/SkillCardTile";
import { EntityTile, EntityGlyph } from "../components/EntityTile";
import type { SkillCardData } from "../components/SkillCardTile";
import type { EntityData } from "../components/EntityTile";

const rarities = ["all", "common", "rare", "epic", "legendary"];

export function AcademyCollection({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState("cards");
  const [rarity, setRarity] = useState("all");
  const [card, setCard] = useState<SkillCardData | null>(null);
  const [entity, setEntity] = useState<EntityData | null>(null);

  const filtered = rarity === "all" ? skillCards : skillCards.filter((c) => c.rarity === rarity);

  return (
    <ScreenShell>
      <div className="mb-3 flex items-center justify-between">
        <span className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">
          Reference catalog
        </span>
        <Button size="sm" variant="ghost" onClick={onBack}>
          ← Academy
        </Button>
      </div>

      <Tabs
        items={[
          { id: "cards", label: `Skill Cards · ${skillCards.length}` },
          { id: "entities", label: `Entities · ${entities.length}` },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "cards" && (
        <>
          <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
            {rarities.map((r) => (
              <button
                key={r}
                onClick={() => setRarity(r)}
                className="min-h-[36px] whitespace-nowrap rounded-full border px-3 text-[12px] capitalize transition-colors"
                style={{
                  borderColor: rarity === r ? "var(--sa-signal)" : "var(--sa-line)",
                  color: rarity === r ? "var(--sa-signal)" : "var(--sa-text-dim)",
                  background: rarity === r ? "color-mix(in srgb, var(--sa-signal) 8%, transparent)" : "transparent",
                }}
              >
                {r}
              </button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            {filtered.map((c) => (
              <SkillCardTile key={c.id} card={c} onClick={() => setCard(c)} />
            ))}
          </div>
        </>
      )}

      {tab === "entities" && (
        <div className="mt-4 space-y-3">
          <p className="text-[12px] leading-snug text-[var(--sa-text-dim)]">
            Entities are observable decision distortions — not monsters. You don&apos;t attack them.
            You learn to notice them acting on you.
          </p>
          {entities.map((e) => (
            <EntityTile key={e.id} entity={e} onClick={() => setEntity(e)} />
          ))}
        </div>
      )}

      <Sheet open={!!card} onClose={() => setCard(null)} title={card?.name}>
        {card && (
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Badge tone="info">{card.rarity}</Badge>
              <Badge tone="neutral">{card.type}</Badge>
            </div>
            <p className="text-[14px] leading-relaxed text-[var(--sa-text)]">{card.body}</p>
            <div className="mt-4 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] p-3">
              <div className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
                Use it when
              </div>
              <p className="mt-1 text-[13px] text-[var(--sa-text-hi)]">{card.short}</p>
            </div>
          </div>
        )}
      </Sheet>

      <Sheet open={!!entity} onClose={() => setEntity(null)} title={entity?.name}>
        {entity && (
          <div>
            <div className="mb-3 flex items-center gap-3">
              <EntityGlyph color={entity.color} size={52} />
              <div>
                <div className="sa-mono text-[11px] uppercase tracking-wide" style={{ color: entity.color }}>
                  {entity.distortion}
                </div>
                <div className="text-[12px] text-[var(--sa-text-dim)]">Decision distortion</div>
              </div>
            </div>
            <Row label="Observed as" value={entity.observed} />
            <Row label="The tell" value={entity.tell} />
            <Row label="Counter tool" value={entity.counter} accent={entity.color} />
          </div>
        )}
      </Sheet>
    </ScreenShell>
  );
}

function Row({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="mt-3 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] p-3">
      <div className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
        {label}
      </div>
      <p className="mt-1 text-[13px]" style={{ color: accent ?? "var(--sa-text-hi)" }}>
        {value}
      </p>
    </div>
  );
}
