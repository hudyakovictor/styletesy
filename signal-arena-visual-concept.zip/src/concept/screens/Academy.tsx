import { useState } from "react";
import { ScreenShell, Card, CardBody, SectionTitle, Button, ProgressBar, Badge, Icon, Sheet } from "../../design-system";
import { data, player, skillCards } from "../data";
import { SkillCardTile } from "../components/SkillCardTile";
import { AcademyCollection } from "./AcademyCollection";
import type { SkillCardData } from "../components/SkillCardTile";

export function Academy({
  collectionOpen,
  setCollectionOpen,
}: {
  collectionOpen: boolean;
  setCollectionOpen: (v: boolean) => void;
}) {
  const [detail, setDetail] = useState<SkillCardData | null>(null);

  if (collectionOpen) {
    return <AcademyCollection onBack={() => setCollectionOpen(false)} />;
  }

  return (
    <ScreenShell grid>
      <Card accent="var(--sa-accent-academy)">
        <CardBody>
          <div className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-accent-academy)]">
            Now studying
          </div>
          <div className="sa-display mt-1 text-[18px] font-semibold text-[var(--sa-text-hi)]">
            {player.currentLesson.track} · {player.currentLesson.unit}
          </div>
          <div className="mt-3">
            <ProgressBar value={player.currentLesson.progress} color="var(--sa-accent-academy)" showValue label="Unit progress" />
          </div>
          <Button variant="signal" size="md" fullWidth className="mt-3">
            Resume unit
          </Button>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Curriculum">Tracks</SectionTitle>
        <div className="space-y-3">
          {data.academyTracks.map((t) => (
            <Card key={t.id} accent={t.accent} interactive>
              <CardBody>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="sa-display text-[15px] font-semibold text-[var(--sa-text-hi)]">
                      {t.name}
                    </div>
                    <p className="mt-0.5 text-[12px] text-[var(--sa-text-dim)]">{t.desc}</p>
                  </div>
                  <Badge tone={t.done === 0 ? "locked" : "neutral"}>
                    {t.done}/{t.units}
                  </Badge>
                </div>
                <div className="mt-3">
                  <ProgressBar value={t.done} max={t.units} color={t.accent} />
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      {/* Nested Vault entry */}
      <div className="mt-5">
        <SectionTitle
          kicker="Reference"
          action={
            <Button size="sm" variant="outline" onClick={() => setCollectionOpen(true)}>
              Open Vault
            </Button>
          }
        >
          Collection / Vault
        </SectionTitle>
        <Card interactive onClick={() => setCollectionOpen(true)}>
          <CardBody className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-[var(--sa-r-md)] bg-[var(--sa-bg-2)] text-[var(--sa-accent-academy)] [&_svg]:h-5 [&_svg]:w-5">
              <Icon.layers />
            </div>
            <div className="flex-1">
              <div className="text-[13px] font-medium text-[var(--sa-text-hi)]">
                {skillCards.length} Skill Cards · {data.entities.length} Entities
              </div>
              <div className="text-[12px] text-[var(--sa-text-dim)]">
                Your catalog of analytical tools and decision distortions.
              </div>
            </div>
            <span className="text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5">
              <Icon.chevron />
            </span>
          </CardBody>
        </Card>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Peek">Featured tool</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          {skillCards.slice(0, 2).map((c) => (
            <SkillCardTile key={c.id} card={c} onClick={() => setDetail(c)} />
          ))}
        </div>
      </div>

      <Sheet open={!!detail} onClose={() => setDetail(null)} title={detail?.name}>
        {detail && (
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Badge tone="info">{detail.rarity}</Badge>
              <Badge tone="neutral">{detail.type}</Badge>
            </div>
            <p className="text-[14px] leading-relaxed text-[var(--sa-text)]">{detail.body}</p>
            <div className="mt-4 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] p-3">
              <div className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
                In one line
              </div>
              <p className="mt-1 text-[13px] text-[var(--sa-text-hi)]">{detail.short}</p>
            </div>
          </div>
        )}
      </Sheet>
    </ScreenShell>
  );
}
