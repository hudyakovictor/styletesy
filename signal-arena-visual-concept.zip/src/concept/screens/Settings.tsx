import { useState } from "react";
import { Sheet, Card, CardBody, Badge, Icon } from "../../design-system";

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onClick}
      className="relative h-6 w-11 shrink-0 rounded-full transition-colors duration-[var(--sa-t-base)]"
      style={{ background: on ? "var(--sa-signal)" : "var(--sa-bg-3)" }}
    >
      <span
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform duration-[var(--sa-t-base)]"
        style={{ transform: on ? "translateX(22px)" : "translateX(2px)" }}
      />
    </button>
  );
}

export function Settings({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [reduceMotion, setReduceMotion] = useState(false);
  const [sound, setSound] = useState(true);
  const [notif, setNotif] = useState(true);
  const [highContrast, setHighContrast] = useState(false);

  const rows: { label: string; sub: string; on: boolean; set: () => void }[] = [
    { label: "Reduce motion", sub: "Minimize animations", on: reduceMotion, set: () => setReduceMotion((v) => !v) },
    { label: "High contrast", sub: "Boost text legibility", on: highContrast, set: () => setHighContrast((v) => !v) },
    { label: "Sound", sub: "Interface cues", on: sound, set: () => setSound((v) => !v) },
    { label: "Case notifications", sub: "Daily case + streak alerts", on: notif, set: () => setNotif((v) => !v) },
  ];

  return (
    <Sheet open={open} onClose={onClose} title="Settings" side="right">
      <Card>
        <CardBody className="p-0">
          {rows.map((r, i) => (
            <div
              key={r.label}
              className="flex items-center justify-between gap-3 px-4 py-3.5"
              style={{ borderTop: i === 0 ? "none" : "1px solid var(--sa-line-soft)" }}
            >
              <div>
                <div className="text-[14px] font-medium text-[var(--sa-text-hi)]">{r.label}</div>
                <div className="text-[12px] text-[var(--sa-text-dim)]">{r.sub}</div>
              </div>
              <Toggle on={r.on} onClick={r.set} label={r.label} />
            </div>
          ))}
        </CardBody>
      </Card>

      <div className="mt-4">
        <span className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">Account</span>
        <Card className="mt-2">
          <CardBody className="p-0">
            {[
              { i: <Icon.brain />, t: "Recalibrate baseline" },
              { i: <Icon.layers />, t: "Language · English" },
              { i: <Icon.eye />, t: "Privacy & data" },
            ].map((x, i) => (
              <button key={x.t} className="flex w-full items-center gap-3 px-4 py-3.5 text-left" style={{ borderTop: i === 0 ? "none" : "1px solid var(--sa-line-soft)" }}>
                <span className="text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5">{x.i}</span>
                <span className="flex-1 text-[14px] text-[var(--sa-text-hi)]">{x.t}</span>
                <span className="text-[var(--sa-text-faint)] [&_svg]:h-4 [&_svg]:w-4"><Icon.chevron /></span>
              </button>
            ))}
          </CardBody>
        </Card>
      </div>

      <div className="mt-4 flex items-center justify-center gap-2">
        <Badge tone="neutral">Signal Arena</Badge>
        <span className="sa-mono text-[11px] text-[var(--sa-text-faint)]">concept build · v0.1</span>
      </div>
    </Sheet>
  );
}
