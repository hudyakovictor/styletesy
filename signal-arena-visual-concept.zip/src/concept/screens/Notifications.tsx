import { Sheet, Icon } from "../../design-system";
import { data } from "../data";
import type { ReactElement } from "react";

const iconFor: Record<string, () => ReactElement> = {
  case: Icon.arena,
  process: Icon.flame,
  academy: Icon.academy,
};

export function Notifications({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="Notifications" side="right">
      <div className="space-y-2.5">
        {data.notifications.map((n) => {
          const IconCmp = iconFor[n.type] ?? Icon.bell;
          return (
            <div
              key={n.id}
              className="flex items-start gap-3 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-3"
              style={{ borderLeftColor: n.unread ? "var(--sa-signal)" : "var(--sa-line)", borderLeftWidth: 2 }}
            >
              <span className="text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">
                <IconCmp />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[13px] font-medium text-[var(--sa-text-hi)]">{n.title}</span>
                  <span className="sa-mono text-[10px] text-[var(--sa-text-faint)]">{n.time}</span>
                </div>
                <p className="mt-0.5 text-[12px] text-[var(--sa-text-dim)]">{n.body}</p>
              </div>
              {n.unread && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-[var(--sa-signal)]" />}
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}
