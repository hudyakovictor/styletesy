import { useState } from "react";
import { Button, SignalMark, Badge, Icon } from "../../design-system";

const questions = [
  {
    q: "The chart broke out on thin volume. Your first move?",
    a: ["Buy the momentum", "Ask what would prove it fake", "Wait, do nothing"],
    signal: 1,
  },
  {
    q: "You just took a loss. Next trade?",
    a: ["Size up to recover", "Same plan, same size", "Step away and review"],
    signal: 2,
  },
  {
    q: "A good outcome means…",
    a: ["Your process was right", "Nothing about your process", "You should repeat it"],
    signal: 1,
  },
];

export function Entry({ onEnter }: { onEnter: () => void }) {
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const isCalib = step > 0 && step <= questions.length;
  const q = isCalib ? questions[step - 1] : null;

  return (
    <div className="sa-grid-bg flex min-h-full flex-1 flex-col">
      <div className="mx-auto flex w-full max-w-[520px] flex-1 flex-col px-5 pb-8 pt-8">
        <div className="flex items-center justify-between">
          <SignalMark />
          <Badge tone="signal">Concept build</Badge>
        </div>

        {step === 0 && (
          <div className="sa-reveal mt-auto">
            <div className="mb-6">
              <div className="sa-mono mb-3 text-[11px] uppercase tracking-[0.3em] text-[var(--sa-signal)]">
                Forensic training
              </div>
              <h1 className="sa-display text-[34px] font-bold leading-[1.05] text-[var(--sa-text-hi)]">
                Read the signal.
                <br />
                Ignore the noise.
              </h1>
              <p className="mt-4 max-w-[340px] text-[15px] leading-relaxed text-[var(--sa-text)]">
                Signal Arena is a decision gym for crypto markets. You do not predict prices — you
                practice the discipline of judging evidence and committing calibrated decisions.
              </p>
            </div>

            <div className="mb-6 grid grid-cols-3 gap-2">
              {[
                { i: <Icon.eye />, t: "Analyze" },
                { i: <Icon.scale />, t: "Decide" },
                { i: <Icon.brain />, t: "Review" },
              ].map((x) => (
                <div
                  key={x.t}
                  className="flex flex-col items-center gap-1.5 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] py-3 text-[var(--sa-text-dim)]"
                >
                  <span className="text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">{x.i}</span>
                  <span className="sa-mono text-[10px] uppercase tracking-wide">{x.t}</span>
                </div>
              ))}
            </div>

            <Button variant="signal" size="lg" fullWidth onClick={() => setStep(1)}>
              Start calibration
            </Button>
            <button
              onClick={onEnter}
              className="mt-3 w-full text-center text-[13px] text-[var(--sa-text-dim)] hover:text-[var(--sa-text)]"
            >
              Skip to app →
            </button>
          </div>
        )}

        {isCalib && q && (
          <div className="sa-reveal mt-8 flex flex-1 flex-col">
            <div className="sa-mono mb-2 text-[11px] uppercase tracking-[0.24em] text-[var(--sa-text-dim)]">
              Calibration · {step}/{questions.length}
            </div>
            <div className="mb-5 flex gap-1">
              {questions.map((_, i) => (
                <div
                  key={i}
                  className="h-1 flex-1 rounded-full"
                  style={{
                    background: i < step ? "var(--sa-signal)" : "var(--sa-bg-3)",
                  }}
                />
              ))}
            </div>
            <h2 className="sa-display text-[22px] font-semibold leading-snug text-[var(--sa-text-hi)]">
              {q.q}
            </h2>
            <div className="mt-5 space-y-2.5">
              {q.a.map((opt, i) => {
                const chosen = picked === i;
                return (
                  <button
                    key={opt}
                    onClick={() => setPicked(i)}
                    className="flex w-full items-center justify-between rounded-[var(--sa-r-md)] border px-4 py-3.5 text-left text-[14px] transition-colors duration-[var(--sa-t-fast)]"
                    style={{
                      borderColor: chosen ? "var(--sa-signal)" : "var(--sa-line)",
                      background: chosen ? "color-mix(in srgb, var(--sa-signal) 10%, var(--sa-bg-1))" : "var(--sa-bg-1)",
                      color: chosen ? "var(--sa-text-hi)" : "var(--sa-text)",
                    }}
                  >
                    {opt}
                    {chosen && (
                      <span className="text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">
                        <Icon.check />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            <div className="mt-auto pt-6">
              <Button
                variant="signal"
                size="lg"
                fullWidth
                disabled={picked === null}
                onClick={() => {
                  setPicked(null);
                  if (step >= questions.length) onEnter();
                  else setStep(step + 1);
                }}
              >
                {step >= questions.length ? "Enter Signal Arena" : "Next"}
              </Button>
              <p className="mt-3 text-center text-[12px] text-[var(--sa-text-faint)]">
                No wrong answers. This sets your starting process baseline.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
