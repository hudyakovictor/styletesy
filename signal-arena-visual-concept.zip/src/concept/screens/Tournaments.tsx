import { ScreenShell, Card, CardBody, Badge, Icon, SectionTitle, Button } from "../../design-system";
import { data } from "../data";

export function Tournaments() {
  const t = data.tournaments;
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-accent-tournament)">
        <CardBody>
          <div className="flex items-center gap-2">
            <Badge tone="locked" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.lock /></span>}>
              Coming soon
            </Badge>
            <span className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
              {t.seasonEta}
            </span>
          </div>
          <div className="sa-display mt-2 text-[24px] font-bold text-[var(--sa-text-hi)]">
            {t.headline}
          </div>
          <p className="mt-1 text-[14px] text-[var(--sa-text-dim)]">{t.sub}</p>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Formats · staged">Planned leagues</SectionTitle>
        <div className="space-y-3">
          {t.preview.map((p) => (
            <Card key={p.id} accent={p.state === "staged" ? "var(--sa-accent-tournament)" : undefined}>
              <CardBody className="flex items-center gap-3">
                <div
                  className="flex h-11 w-11 items-center justify-center rounded-[var(--sa-r-md)] bg-[var(--sa-bg-2)] [&_svg]:h-5 [&_svg]:w-5"
                  style={{ color: p.state === "staged" ? "var(--sa-accent-tournament)" : "var(--sa-text-dim)" }}
                >
                  {p.state === "staged" ? <Icon.tournament /> : <Icon.lock />}
                </div>
                <div className="flex-1">
                  <div className="text-[14px] font-medium text-[var(--sa-text-hi)]">{p.name}</div>
                  <div className="text-[12px] text-[var(--sa-text-dim)]">{p.format}</div>
                </div>
                <Badge tone={p.state === "staged" ? "info" : "locked"}>{p.state}</Badge>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Ranked by discipline">Leaderboard preview</SectionTitle>
        <Card>
          <CardBody className="p-0">
            {t.leaderboardPreview.map((row, i) => (
              <div
                key={row.rank}
                className="flex items-center gap-3 px-4 py-3"
                style={{
                  background: row.you ? "color-mix(in srgb, var(--sa-signal) 8%, transparent)" : "transparent",
                  borderTop: i === 0 ? "none" : "1px solid var(--sa-line-soft)",
                }}
              >
                <span className="sa-mono w-6 text-[13px] font-bold" style={{ color: row.rank <= 3 ? "var(--sa-noise)" : "var(--sa-text-dim)" }}>
                  {row.rank}
                </span>
                <span className="flex-1 text-[13px] font-medium" style={{ color: row.you ? "var(--sa-signal)" : "var(--sa-text-hi)" }}>
                  {row.handle}{row.you && " (you)"}
                </span>
                <span className="sa-mono text-[13px] font-semibold text-[var(--sa-text-hi)]">{row.process}</span>
              </div>
            ))}
          </CardBody>
        </Card>
        <p className="mt-2 text-[11px] text-[var(--sa-text-faint)]">
          Preview only — no live tournament engine or competitive logic in this concept.
        </p>
      </div>

      <div className="mt-6">
        <Button variant="locked" size="lg" fullWidth disabled>
          Notify me at launch
        </Button>
      </div>
    </ScreenShell>
  );
}
