import { ScreenShell, Card, CardBody, Button, Badge, Icon, ProgressBar, SectionTitle } from "../../design-system";
import { useNav } from "../router";
import { reveal, entityById } from "../data";
import { EntityGlyph } from "../components/EntityTile";

export function RevealScoreDebrief() {
  const nav = useNav();
  const ent = entityById(reveal.entityRevealed);

  return (
    <ScreenShell>
      {/* Historical Reveal */}
      <div className="sa-reveal">
        <Card accent={reveal.decisionWasRight ? "var(--sa-signal)" : "var(--sa-danger)"} glow={reveal.decisionWasRight}>
          <CardBody>
            <div className="flex items-center gap-2">
              <span className="text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">
                <Icon.eye />
              </span>
              <span className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">
                Historical reveal
              </span>
            </div>
            <p className="mt-2 text-[15px] leading-relaxed text-[var(--sa-text-hi)]">{reveal.outcome}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge tone={reveal.decisionWasRight ? "signal" : "danger"}>
                {reveal.decisionWasRight ? "Outcome matched" : "Outcome went against you"}
              </Badge>
              <Badge tone={reveal.processVerdict === "sound" ? "signal" : "noise"}>
                Process: {reveal.processVerdict}
              </Badge>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Signal-vs-noise honesty note */}
      <div className="mt-3 rounded-[var(--sa-r-md)] border-l-2 border-[var(--sa-noise)] bg-[var(--sa-bg-1)] p-3">
        <div className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-noise)]">
          The hard truth
        </div>
        <p className="mt-1 text-[13px] leading-snug text-[var(--sa-text)]">{reveal.note}</p>
      </div>

      {/* Score */}
      <div className="mt-5">
        <SectionTitle kicker="Scoring" action={
          <span className="sa-display text-[22px] font-bold text-[var(--sa-signal)]">
            {reveal.processScore}<span className="text-[var(--sa-text-faint)] text-[15px]">/{reveal.processMax}</span>
          </span>
        }>
          Process score
        </SectionTitle>
        <Card>
          <CardBody className="space-y-3">
            {reveal.scoreBreakdown.map((b) => (
              <div key={b.id}>
                <div className="mb-1 flex items-center justify-between text-[12px]">
                  <span className="text-[var(--sa-text)]">{b.label}</span>
                  <span className="sa-mono font-semibold" style={{ color: b.points === 0 ? "var(--sa-danger)" : b.points === b.max ? "var(--sa-signal)" : "var(--sa-noise)" }}>
                    {b.points}/{b.max}
                  </span>
                </div>
                <ProgressBar
                  value={b.points}
                  max={b.max}
                  color={b.points === 0 ? "var(--sa-danger)" : b.points === b.max ? "var(--sa-signal)" : "var(--sa-noise)"}
                />
              </div>
            ))}
          </CardBody>
        </Card>
      </div>

      {/* Debrief — entity revealed */}
      <div className="mt-5">
        <SectionTitle kicker="Debrief">What was acting on you</SectionTitle>
        {ent && (
          <Card accent={ent.color}>
            <CardBody className="flex items-start gap-3">
              <EntityGlyph color={ent.color} size={48} />
              <div className="min-w-0">
                <div className="sa-display text-[15px] font-bold text-[var(--sa-text-hi)]">{ent.name}</div>
                <div className="sa-mono text-[10px] uppercase tracking-wide" style={{ color: ent.color }}>
                  {ent.distortion}
                </div>
                <p className="mt-1.5 text-[12px] leading-snug text-[var(--sa-text-dim)]">
                  {ent.tell} Counter it next time with <span className="text-[var(--sa-text-hi)]">{ent.counter}</span>.
                </p>
              </div>
            </CardBody>
          </Card>
        )}
      </div>

      <div className="mt-6 space-y-2">
        <Button variant="signal" size="lg" fullWidth onClick={() => nav.goArena("rematch")}>
          Continue to rematch
        </Button>
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("home")}>
          Return to Arena
        </Button>
      </div>
    </ScreenShell>
  );
}
