import { Sheet, Card, CardBody, Badge, Button, Icon, ProgressBar } from "../../design-system";
import { player, skillCards, data } from "../data";

export function Profile({ open, onClose, onOpenVault }: { open: boolean; onClose: () => void; onOpenVault: () => void }) {
  return (
    <Sheet open={open} onClose={onClose} title="Profile" side="right">
      <div className="flex items-center gap-3">
        <div className="flex h-16 w-16 items-center justify-center rounded-[var(--sa-r-lg)] border border-[var(--sa-signal-dim)] bg-[var(--sa-bg-2)] sa-display text-[22px] font-bold text-[var(--sa-signal)]">
          {player.avatar}
        </div>
        <div>
          <div className="sa-display text-[18px] font-bold text-[var(--sa-text-hi)]">{player.handle}</div>
          <div className="text-[12px] text-[var(--sa-text-dim)]">Lvl {player.level} · {player.levelTitle}</div>
          <div className="mt-1"><Badge tone="signal">Process {player.processScore}</Badge></div>
        </div>
      </div>

      <div className="mt-4">
        <ProgressBar value={player.xp} max={player.xpToNext} label="XP" color="var(--sa-signal)" showValue />
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        {[
          { i: <Icon.star />, v: player.stars, l: "Stars", c: "var(--sa-noise)" },
          { i: <Icon.coin />, v: player.coins, l: "Coins", c: "var(--sa-accent-hub)" },
          { i: <Icon.flame />, v: `${player.streakDays}d`, l: "Streak", c: "var(--sa-signal)" },
        ].map((s) => (
          <Card key={s.l}>
            <CardBody className="p-3">
              <span className="[&_svg]:mx-auto [&_svg]:h-5 [&_svg]:w-5" style={{ color: s.c }}>{s.i}</span>
              <div className="sa-display mt-1 text-[16px] font-bold text-[var(--sa-text-hi)]">{s.v}</div>
              <div className="sa-mono text-[9px] uppercase tracking-wide text-[var(--sa-text-dim)]">{s.l}</div>
            </CardBody>
          </Card>
        ))}
      </div>

      <div className="mt-5">
        <div className="mb-2 flex items-center justify-between">
          <span className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">Loadout</span>
          <Button size="sm" variant="ghost" onClick={onOpenVault}>Vault →</Button>
        </div>
        <div className="flex gap-2">
          {skillCards.slice(0, 3).map((c) => (
            <div key={c.id} className="flex-1 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-2.5 text-center">
              <div className="sa-display text-[12px] font-semibold text-[var(--sa-text-hi)]">{c.name}</div>
              <div className="sa-mono mt-0.5 text-[9px] uppercase text-[var(--sa-text-dim)]">{c.type}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <span className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">Entities encountered</span>
        <div className="mt-2 flex flex-wrap gap-2">
          {data.entities.map((e) => (
            <span key={e.id} className="rounded-full border px-3 py-1 sa-mono text-[11px] font-semibold" style={{ borderColor: e.color, color: e.color }}>
              {e.name}
            </span>
          ))}
        </div>
      </div>
    </Sheet>
  );
}
