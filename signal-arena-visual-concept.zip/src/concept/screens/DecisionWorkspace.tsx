import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  Button,
  Badge,
  Icon,
  MarketWorkspaceSlot,
  Modal,
} from "../../design-system";
import { useNav } from "../router";
import { scenario, skillCards } from "../data";

export function DecisionWorkspace() {
  const nav = useNav();
  const [hypothesis, setHypothesis] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(50);
  const [selectedCards, setSelectedCards] = useState<string[]>([]);
  const [confirmSeal, setConfirmSeal] = useState(false);

  const toggleCard = (id: string) =>
    setSelectedCards((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length >= 3 ? prev : [...prev, id]
    );

  const ready = hypothesis !== null;

  return (
    <ScreenShell>
      {/* Hierarchy header */}
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">
            Decision Workspace
          </div>
          <div className="sa-display text-[16px] font-semibold text-[var(--sa-text-hi)]">
            {scenario.codename}
          </div>
        </div>
        <Badge tone="noise">signal vs noise</Badge>
      </div>

      {/* Reserved market slot — no pseudo-chart */}
      <MarketWorkspaceSlot height={180} caption="Market workspace · reserved" />

      {/* Step 1: Evidence weighting (cards/evidence) */}
      <StepHead n={1} title="Weigh the evidence" />
      <div className="space-y-2">
        {scenario.evidence.map((e) => (
          <div
            key={e.id}
            className="flex items-center justify-between gap-3 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-3"
          >
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="sa-mono text-[11px] uppercase tracking-wide text-[var(--sa-text-dim)]">
                  {e.tag}
                </span>
              </div>
              <p className="mt-0.5 truncate text-[12px] text-[var(--sa-text)]">{e.text}</p>
            </div>
            <span
              className="h-2.5 w-2.5 shrink-0 rounded-full"
              style={{
                background:
                  e.quality === "signal"
                    ? "var(--sa-signal)"
                    : e.quality === "weak"
                    ? "var(--sa-noise)"
                    : "var(--sa-danger)",
              }}
              aria-label={e.quality}
            />
          </div>
        ))}
      </div>

      {/* Step 2: Analytical tools (choose up to 3) */}
      <StepHead n={2} title="Apply analytical tools" hint={`${selectedCards.length}/3`} />
      <div className="grid grid-cols-2 gap-2">
        {skillCards.slice(0, 6).map((c) => {
          const on = selectedCards.includes(c.id);
          return (
            <button
              key={c.id}
              onClick={() => toggleCard(c.id)}
              aria-pressed={on}
              className="flex items-center gap-2 rounded-[var(--sa-r-md)] border p-2.5 text-left transition-colors duration-[var(--sa-t-fast)]"
              style={{
                borderColor: on ? "var(--sa-signal)" : "var(--sa-line)",
                background: on ? "color-mix(in srgb, var(--sa-signal) 8%, var(--sa-bg-1))" : "var(--sa-bg-1)",
              }}
            >
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[var(--sa-r-sm)] [&_svg]:h-3.5 [&_svg]:w-3.5"
                style={{ background: on ? "var(--sa-signal)" : "var(--sa-bg-3)", color: on ? "#04140b" : "var(--sa-text-dim)" }}
              >
                {on ? <Icon.check /> : <Icon.layers />}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[12px] font-medium text-[var(--sa-text-hi)]">
                  {c.name}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Step 3: Hypothesis */}
      <StepHead n={3} title="Commit a hypothesis" />
      <div className="space-y-2">
        {scenario.hypotheses.map((h) => {
          const on = hypothesis === h.id;
          return (
            <button
              key={h.id}
              onClick={() => setHypothesis(h.id)}
              aria-pressed={on}
              className="flex w-full items-start gap-3 rounded-[var(--sa-r-md)] border p-3 text-left transition-colors duration-[var(--sa-t-fast)]"
              style={{
                borderColor: on ? "var(--sa-signal)" : "var(--sa-line)",
                background: on ? "color-mix(in srgb, var(--sa-signal) 8%, var(--sa-bg-1))" : "var(--sa-bg-1)",
              }}
            >
              <span
                className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border"
                style={{ borderColor: on ? "var(--sa-signal)" : "var(--sa-line)" }}
              >
                {on && <span className="h-2.5 w-2.5 rounded-full bg-[var(--sa-signal)]" />}
              </span>
              <span>
                <span className="block text-[14px] font-medium text-[var(--sa-text-hi)]">{h.label}</span>
                <span className="mt-0.5 block text-[12px] text-[var(--sa-text-dim)]">{h.note}</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Step 4: Confidence */}
      <StepHead n={4} title="Calibrate confidence" />
      <Card>
        <CardBody>
          <div className="flex items-center justify-between">
            <span className="text-[12px] text-[var(--sa-text-dim)]">How sure are you?</span>
            <span className="sa-mono text-[20px] font-bold text-[var(--sa-text-hi)]">{confidence}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            value={confidence}
            onChange={(e) => setConfidence(Number(e.target.value))}
            aria-label="Confidence"
            className="mt-3 w-full accent-[var(--sa-signal)]"
          />
          <div className="mt-1 flex justify-between text-[10px] sa-mono uppercase tracking-wide text-[var(--sa-text-faint)]">
            <span>Guessing</span>
            <span>Certain</span>
          </div>
          <p className="mt-2 text-[11px] text-[var(--sa-text-faint)]">
            Overconfidence is scored against you, even when the outcome agrees.
          </p>
        </CardBody>
      </Card>

      {/* Seal CTA */}
      <div className="mt-6 space-y-2">
        <Button
          variant="signal"
          size="lg"
          fullWidth
          disabled={!ready}
          onClick={() => setConfirmSeal(true)}
          icon={<span className="[&_svg]:h-5 [&_svg]:w-5"><Icon.seal /></span>}
        >
          Seal decision
        </Button>
        {!ready && (
          <p className="text-center text-[12px] text-[var(--sa-text-faint)]">
            Commit a hypothesis to seal.
          </p>
        )}
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("brief")}>
          Back to brief
        </Button>
      </div>

      {/* Decision Seal confirmation → predetermined transition to Reveal */}
      <Modal open={confirmSeal} onClose={() => setConfirmSeal(false)} title="Seal this decision?">
        <p className="text-[13px] leading-relaxed text-[var(--sa-text)]">
          Once sealed, your reasoning is locked before the outcome is revealed. This is the point of
          the exercise — commit, then face what actually happened.
        </p>
        <div className="mt-4 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] p-3">
          <Row label="Hypothesis" value={scenario.hypotheses.find((h) => h.id === hypothesis)?.label ?? "—"} />
          <Row label="Confidence" value={`${confidence}%`} />
          <Row label="Tools applied" value={`${selectedCards.length}`} />
        </div>
        <div className="mt-4 flex gap-2">
          <Button variant="ghost" fullWidth onClick={() => setConfirmSeal(false)}>
            Review
          </Button>
          <Button
            variant="signal"
            fullWidth
            onClick={() => {
              setConfirmSeal(false);
              nav.goArena("reveal");
            }}
          >
            Seal & reveal
          </Button>
        </div>
      </Modal>
    </ScreenShell>
  );
}

function StepHead({ n, title, hint }: { n: number; title: string; hint?: string }) {
  return (
    <div className="mb-2 mt-6 flex items-center gap-2">
      <span className="flex h-6 w-6 items-center justify-center rounded-full border border-[var(--sa-line)] bg-[var(--sa-bg-2)] sa-mono text-[11px] font-bold text-[var(--sa-signal)]">
        {n}
      </span>
      <h3 className="sa-display flex-1 text-[15px] font-semibold text-[var(--sa-text-hi)]">{title}</h3>
      {hint && <span className="sa-mono text-[11px] text-[var(--sa-text-dim)]">{hint}</span>}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="sa-mono text-[11px] uppercase tracking-wide text-[var(--sa-text-dim)]">{label}</span>
      <span className="text-[13px] font-medium text-[var(--sa-text-hi)]">{value}</span>
    </div>
  );
}
