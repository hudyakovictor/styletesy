import { ScreenShell, Card, CardBody, SectionTitle, Button, ProgressBar, Badge, Icon } from "../../design-system";
import { useNav } from "../router";
import { player, scenario, data } from "../data";

export function Hub() {
  const nav = useNav();
  return (
    <ScreenShell grid>
      {/* Level + process pulse */}
      <Card className="overflow-hidden">
        <CardBody>
          <div className="flex items-start justify-between">
            <div>
              <div className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-text-dim)]">
                Level {player.level} · {player.levelTitle}
              </div>
              <div className="sa-display mt-1 text-[22px] font-bold text-[var(--sa-text-hi)]">
                Process Score {player.processScore}
              </div>
            </div>
            <Badge tone="signal" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.flame /></span>}>
              {player.streakDays}d streak
            </Badge>
          </div>
          <div className="mt-3">
            <ProgressBar
              value={player.processScore}
              max={100}
              label="Discipline"
              color="var(--sa-signal)"
              showValue
            />
          </div>
          <p className="mt-3 text-[12px] leading-snug text-[var(--sa-text-dim)]">
            Your score tracks how well you reason — not how much you win. Good outcomes don&apos;t
            prove a good process.
          </p>
        </CardBody>
      </Card>

      {/* Daily case CTA */}
      <div className="mt-4">
        <SectionTitle kicker="Priority" action={<Badge tone="noise">expires 9h</Badge>}>
          Daily Case
        </SectionTitle>
        <Card accent="var(--sa-signal)" interactive onClick={() => nav.goSection("arena")}>
          <CardBody>
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <div className="sa-display text-[17px] font-semibold text-[var(--sa-text-hi)]">
                  {scenario.codename}
                </div>
                <div className="mt-0.5 text-[12px] text-[var(--sa-text-dim)]">
                  {scenario.asset} · {scenario.difficulty}
                </div>
              </div>
              <div className="text-[var(--sa-signal)] [&_svg]:h-6 [&_svg]:w-6">
                <Icon.chevron />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Badge tone="signal" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.star /></span>}>
                +{scenario.reward.stars}
              </Badge>
              <Badge tone="neutral" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.bolt /></span>}>
                1 energy
              </Badge>
              <Badge tone="info">+{scenario.reward.process} process</Badge>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Continue learning */}
      <div className="mt-5">
        <SectionTitle kicker="Academy" action={<Button size="sm" variant="ghost" onClick={() => nav.goSection("academy")}>Open</Button>}>
          Continue lesson
        </SectionTitle>
        <Card interactive accent="var(--sa-accent-academy)" onClick={() => nav.goSection("academy")}>
          <CardBody>
            <div className="text-[12px] sa-mono uppercase tracking-wide text-[var(--sa-accent-academy)]">
              {player.currentLesson.track}
            </div>
            <div className="sa-display mt-1 text-[15px] font-semibold text-[var(--sa-text-hi)]">
              {player.currentLesson.unit}
            </div>
            <div className="mt-3">
              <ProgressBar value={player.currentLesson.progress} color="var(--sa-accent-academy)" showValue label="Unit progress" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Quick nav grid */}
      <div className="mt-5">
        <SectionTitle kicker="Sections">Jump in</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          <QuickTile icon={<Icon.arena />} label="Arena" sub="Practice loop" color="var(--sa-accent-arena)" onClick={() => nav.goSection("arena")} />
          <QuickTile icon={<Icon.academy />} label="Academy" sub="Learn + Vault" color="var(--sa-accent-academy)" onClick={() => nav.goSection("academy")} />
          <QuickTile icon={<Icon.shop />} label="Shop" sub="Case skins" color="var(--sa-accent-shop)" onClick={() => nav.goSection("shop")} />
          <QuickTile icon={<Icon.tournament />} label="Tournaments" sub="Coming soon" color="var(--sa-accent-tournament)" onClick={() => nav.goSection("tournament")} />
        </div>
      </div>

      {/* Recent debrief teaser */}
      <div className="mt-5">
        <SectionTitle kicker="Last decision">Your recent review</SectionTitle>
        <Card>
          <CardBody className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-[var(--sa-r-md)] bg-[var(--sa-signal)]/10 text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">
              <Icon.check />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-medium text-[var(--sa-text-hi)]">
                Sound process · {data.reveal.processScore}/{data.reveal.processMax}
              </div>
              <div className="truncate text-[12px] text-[var(--sa-text-dim)]">
                You read the noise but under-committed confidence.
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={() => nav.goSection("arena")}>
              Debrief
            </Button>
          </CardBody>
        </Card>
      </div>
    </ScreenShell>
  );
}

function QuickTile({
  icon,
  label,
  sub,
  color,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  sub: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col gap-2 rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-4 text-left transition-[transform,border-color] duration-[var(--sa-t-base)] hover:-translate-y-0.5"
    >
      <span className="[&_svg]:h-6 [&_svg]:w-6" style={{ color }}>
        {icon}
      </span>
      <div>
        <div className="sa-display text-[15px] font-semibold text-[var(--sa-text-hi)]">{label}</div>
        <div className="text-[11px] text-[var(--sa-text-dim)]">{sub}</div>
      </div>
    </button>
  );
}
