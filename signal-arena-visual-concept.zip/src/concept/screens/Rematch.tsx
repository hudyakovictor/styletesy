import { ScreenShell, Card, CardBody, Button, Badge, Icon, SectionTitle } from "../../design-system";
import { useNav } from "../router";
import { scenario, reveal, player } from "../data";

export function Rematch() {
  const nav = useNav();
  return (
    <ScreenShell grid>
      <div className="sa-reveal">
        <Card accent="var(--sa-signal)" glow>
          <CardBody className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[var(--sa-signal)]/12 text-[var(--sa-signal)] [&_svg]:h-7 [&_svg]:w-7">
              <Icon.check />
            </div>
            <div className="sa-display mt-3 text-[20px] font-bold text-[var(--sa-text-hi)]">
              Case closed
            </div>
            <p className="mt-1 text-[13px] text-[var(--sa-text-dim)]">
              {scenario.codename} · +{reveal.processScore} process
            </p>
            <div className="mt-4 flex justify-center gap-2">
              <Badge tone="signal" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.star /></span>}>
                +{scenario.reward.stars}
              </Badge>
              <Badge tone="neutral" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.coin /></span>}>
                +{scenario.reward.coins}
              </Badge>
              <Badge tone="info">Lvl {player.level}</Badge>
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Rematch">Run it again, harder</SectionTitle>
        <div className="space-y-3">
          <Card interactive accent="var(--sa-signal)" onClick={() => nav.goArena("brief")}>
            <CardBody className="flex items-center gap-3">
              <span className="text-[var(--sa-signal)] [&_svg]:h-6 [&_svg]:w-6"><Icon.target /></span>
              <div className="flex-1">
                <div className="text-[14px] font-medium text-[var(--sa-text-hi)]">Same case, blind reasons</div>
                <div className="text-[12px] text-[var(--sa-text-dim)]">Re-decide without seeing your last answer.</div>
              </div>
              <span className="text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5"><Icon.chevron /></span>
            </CardBody>
          </Card>
          <Card interactive accent="var(--sa-accent-tournament)" onClick={() => nav.goArena("home")}>
            <CardBody className="flex items-center gap-3">
              <span className="text-[var(--sa-accent-tournament)] [&_svg]:h-6 [&_svg]:w-6"><Icon.layers /></span>
              <div className="flex-1">
                <div className="text-[14px] font-medium text-[var(--sa-text-hi)]">New case</div>
                <div className="text-[12px] text-[var(--sa-text-dim)]">Fresh scenario from the queue.</div>
              </div>
              <span className="text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5"><Icon.chevron /></span>
            </CardBody>
          </Card>
        </div>
      </div>

      <div className="mt-6">
        <Button variant="outline" size="lg" fullWidth onClick={() => nav.goArena("home")}>
          Return to Arena
        </Button>
      </div>
    </ScreenShell>
  );
}
