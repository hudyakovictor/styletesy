import { ScreenShell, Card, CardBody, Button, Badge, Icon, SectionTitle } from "../../design-system";
import { useNav } from "../router";
import { scenario, entityById } from "../data";

const qualityTone: Record<string, "signal" | "noise" | "danger" | "neutral"> = {
  signal: "signal",
  weak: "noise",
  noise: "danger",
};

export function ScenarioBrief() {
  const nav = useNav();
  return (
    <ScreenShell>
      <Card accent="var(--sa-signal)">
        <CardBody>
          <div className="flex items-center justify-between">
            <Badge tone="signal">{scenario.difficulty}</Badge>
            <span className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
              Case {scenario.id}
            </span>
          </div>
          <div className="sa-display mt-2 text-[22px] font-bold text-[var(--sa-text-hi)]">
            {scenario.codename}
          </div>
          <div className="mt-0.5 text-[13px] text-[var(--sa-text-dim)]">
            {scenario.asset} · {scenario.era}
          </div>
          <p className="mt-3 text-[14px] leading-relaxed text-[var(--sa-text)]">{scenario.brief}</p>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Case file">Evidence on the board</SectionTitle>
        <div className="space-y-2.5">
          {scenario.evidence.map((e) => (
            <Card key={e.id}>
              <CardBody className="flex items-start gap-3 p-3">
                <Badge tone={qualityTone[e.quality]}>{e.tag}</Badge>
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] leading-snug text-[var(--sa-text)]">{e.text}</p>
                  <div className="sa-mono mt-1 text-[10px] uppercase tracking-wide" style={{
                    color:
                      e.quality === "signal"
                        ? "var(--sa-signal)"
                        : e.quality === "weak"
                        ? "var(--sa-noise)"
                        : "var(--sa-danger)",
                  }}>
                    {e.quality === "signal" ? "likely signal" : e.quality === "weak" ? "weak / unconfirmed" : "likely noise"}
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Watch for">Suspected distortions</SectionTitle>
        <div className="flex flex-wrap gap-2">
          {scenario.suspectedEntities.map((id) => {
            const e = entityById(id);
            if (!e) return null;
            return (
              <div
                key={id}
                className="flex items-center gap-2 rounded-full border px-3 py-1.5"
                style={{ borderColor: e.color, background: `color-mix(in srgb, ${e.color} 8%, transparent)` }}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: e.color }} aria-hidden />
                <span className="sa-mono text-[12px] font-semibold" style={{ color: e.color }}>
                  {e.name}
                </span>
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[12px] text-[var(--sa-text-faint)]">
          These may be acting on your judgment. Noticing them is half the work.
        </p>
      </div>

      <div className="mt-6 space-y-2">
        <Button variant="signal" size="lg" fullWidth onClick={() => nav.goArena("workspace")} icon={<span className="[&_svg]:h-5 [&_svg]:w-5"><Icon.eye /></span>}>
          Open Decision Workspace
        </Button>
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("home")}>
          Back to modes
        </Button>
      </div>
    </ScreenShell>
  );
}
