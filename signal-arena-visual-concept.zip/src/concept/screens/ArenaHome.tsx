import { ScreenShell, Card, CardBody, SectionTitle, Button, Badge, Icon, ProgressBar } from "../../design-system";
import { useNav } from "../router";
import { data, player } from "../data";

export function ArenaHome() {
  const nav = useNav();
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-signal)" glow>
        <CardBody>
          <div className="flex items-center justify-between">
            <div>
              <div className="sa-mono text-[10px] uppercase tracking-[0.2em] text-[var(--sa-signal)]">
                Arena · practice loop
              </div>
              <div className="sa-display mt-1 text-[20px] font-bold text-[var(--sa-text-hi)]">
                Enter a case
              </div>
            </div>
            <div className="text-[var(--sa-signal)] [&_svg]:h-8 [&_svg]:w-8">
              <Icon.arena />
            </div>
          </div>
          <p className="mt-2 text-[12px] leading-snug text-[var(--sa-text-dim)]">
            Brief → Decision Workspace → Seal → Reveal → Debrief → Rematch. One clean loop.
          </p>
          <div className="mt-3 flex items-center gap-2">
            <Badge tone="signal" icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.bolt /></span>}>
              {player.energy}/{player.energyMax} energy
            </Badge>
            <span className="text-[11px] text-[var(--sa-text-faint)]">refills in {player.energyRefillMin}m</span>
          </div>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Select mode">Modes</SectionTitle>
        <div className="space-y-3">
          {data.arenaModes.map((m) => (
            <Card key={m.id} accent={m.accent} interactive={!m.locked}>
              <CardBody>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="sa-display text-[16px] font-semibold text-[var(--sa-text-hi)]">
                        {m.name}
                      </div>
                      {m.locked && (
                        <span className="text-[var(--sa-text-dim)] [&_svg]:h-4 [&_svg]:w-4">
                          <Icon.lock />
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 text-[12px] text-[var(--sa-text-dim)]">{m.desc}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <Badge tone="neutral">{m.tag}</Badge>
                      <Badge tone={m.locked ? "locked" : "signal"} icon={<span className="[&_svg]:h-3 [&_svg]:w-3"><Icon.bolt /></span>}>
                        {m.energy}
                      </Badge>
                    </div>
                  </div>
                  {m.locked ? (
                    <Button size="sm" variant="locked" disabled>
                      Lvl 9
                    </Button>
                  ) : (
                    <Button size="sm" variant="signal" onClick={() => nav.goArena("brief")}>
                      Enter
                    </Button>
                  )}
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Season">Your Arena standing</SectionTitle>
        <Card>
          <CardBody>
            <div className="grid grid-cols-3 gap-3 text-center">
              {[
                { v: player.processScore, l: "Process" },
                { v: "12th", l: "Rank" },
                { v: `${player.streakDays}d`, l: "Streak" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="sa-display text-[20px] font-bold text-[var(--sa-text-hi)]">{s.v}</div>
                  <div className="sa-mono text-[10px] uppercase tracking-wide text-[var(--sa-text-dim)]">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <ProgressBar value={player.xp} max={player.xpToNext} label="XP to next analyst tier" color="var(--sa-signal)" showValue />
            </div>
          </CardBody>
        </Card>
      </div>
    </ScreenShell>
  );
}
