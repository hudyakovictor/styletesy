import raw from "../../content-library/mock-data.json";

export const data = raw;
export type MockData = typeof raw;

export const player = raw.player;
export const skillCards = raw.skillCards;
export const entities = raw.entities;
export const scenario = raw.scenario;
export const reveal = raw.reveal;

export const entityById = (id: string) => entities.find((e) => e.id === id);
export const cardByName = (name: string) => skillCards.find((c) => c.name === name);

export const rarityColor: Record<string, string> = {
  common: "var(--sa-rare-common)",
  rare: "var(--sa-rare-rare)",
  epic: "var(--sa-rare-epic)",
  legendary: "var(--sa-rare-legendary)",
};
