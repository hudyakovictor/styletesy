import { useEffect } from "react";
import type { ReactNode } from "react";

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <button aria-label="Close" onClick={onClose} className="absolute inset-0 bg-black/70" />
      <div className="relative z-10 w-full max-w-md rounded-[var(--sa-r-lg)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-5 shadow-[var(--sa-shadow-card)] sa-reveal">
        {title && (
          <h3 className="sa-display mb-3 text-lg font-semibold text-[var(--sa-text-hi)]">{title}</h3>
        )}
        {children}
      </div>
    </div>
  );
}
