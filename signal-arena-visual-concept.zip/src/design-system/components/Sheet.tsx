import { cn } from "../../utils/cn";
import { useEffect } from "react";
import type { ReactNode } from "react";

/* Bottom sheet / drawer for mobile-first surfaces */
export function Sheet({
  open,
  onClose,
  title,
  children,
  side = "bottom",
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  side?: "bottom" | "right";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label={title}>
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <div
        className={cn(
          "relative z-10 flex flex-col border-[var(--sa-line)] bg-[var(--sa-bg-1)] sa-reveal",
          side === "bottom"
            ? "mt-auto w-full max-h-[85vh] rounded-t-[var(--sa-r-xl)] border-t"
            : "ml-auto h-full w-[min(420px,90vw)] border-l"
        )}
      >
        {side === "bottom" && (
          <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-[var(--sa-line)]" />
        )}
        <div className="flex items-center justify-between px-5 pb-3 pt-4">
          {title && (
            <h3 className="sa-display text-base font-semibold text-[var(--sa-text-hi)]">{title}</h3>
          )}
          <button
            onClick={onClose}
            aria-label="Close"
            className="ml-auto flex h-9 w-9 items-center justify-center rounded-full text-[var(--sa-text-dim)] hover:bg-[var(--sa-bg-2)] hover:text-[var(--sa-text-hi)]"
          >
            ✕
          </button>
        </div>
        <div className="overflow-y-auto px-5 pb-8">{children}</div>
      </div>
    </div>
  );
}
