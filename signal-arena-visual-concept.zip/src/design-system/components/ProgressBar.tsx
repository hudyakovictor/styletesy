import { cn } from "../../utils/cn";

export function ProgressBar({
  value,
  max = 100,
  color = "var(--sa-signal)",
  label,
  className,
  showValue,
}: {
  value: number;
  max?: number;
  color?: string;
  label?: string;
  className?: string;
  showValue?: boolean;
}) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className={cn("w-full", className)}>
      {(label || showValue) && (
        <div className="mb-1 flex items-center justify-between text-[11px] sa-mono uppercase tracking-wide text-[var(--sa-text-dim)]">
          <span>{label}</span>
          {showValue && (
            <span className="text-[var(--sa-text)]">
              {value}
              <span className="text-[var(--sa-text-faint)]">/{max}</span>
            </span>
          )}
        </div>
      )}
      <div
        className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--sa-bg-3)]"
        role="progressbar"
        aria-valuenow={value}
        aria-valuemax={max}
        aria-label={label}
      >
        <div
          className="h-full rounded-full transition-[width] duration-[var(--sa-t-slow)]"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
    </div>
  );
}
