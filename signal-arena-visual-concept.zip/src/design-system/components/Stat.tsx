import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

export function Stat({
  icon,
  label,
  value,
  color,
  className,
}: {
  icon?: ReactNode;
  label: string;
  value: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-1.5 rounded-[var(--sa-r-sm)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] px-2.5 py-1.5",
        className
      )}
    >
      {icon && (
        <span className="text-sm" style={{ color }} aria-hidden>
          {icon}
        </span>
      )}
      <span className="sa-mono text-sm font-semibold text-[var(--sa-text-hi)]">{value}</span>
      <span className="sr-only">{label}</span>
    </div>
  );
}
