import { cn } from "../../utils/cn";
import { Icon } from "./icons";
import type { ReactElement } from "react";

export type RootSection = "hub" | "academy" | "arena" | "shop" | "tournament";

const items: { id: RootSection; label: string; Icon: () => ReactElement; accent: string }[] = [
  { id: "hub", label: "Hub", Icon: Icon.hub, accent: "var(--sa-accent-hub)" },
  { id: "academy", label: "Academy", Icon: Icon.academy, accent: "var(--sa-accent-academy)" },
  { id: "arena", label: "Arena", Icon: Icon.arena, accent: "var(--sa-accent-arena)" },
  { id: "shop", label: "Shop", Icon: Icon.shop, accent: "var(--sa-accent-shop)" },
  { id: "tournament", label: "Tournaments", Icon: Icon.tournament, accent: "var(--sa-accent-tournament)" },
];

export function BottomNav({
  active,
  onChange,
}: {
  active: RootSection;
  onChange: (id: RootSection) => void;
}) {
  return (
    <nav
      aria-label="Primary"
      className="sticky bottom-0 z-30 border-t border-[var(--sa-line)] bg-[var(--sa-bg-0)]/92 backdrop-blur-md"
    >
      <ul className="mx-auto flex max-w-[520px] items-stretch justify-around px-1 pb-[max(env(safe-area-inset-bottom),8px)] pt-1.5">
        {items.map((it) => {
          const isActive = it.id === active;
          const IconCmp = it.Icon;
          return (
            <li key={it.id} className="flex-1">
              <button
                onClick={() => onChange(it.id)}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "flex min-h-[52px] w-full flex-col items-center justify-center gap-0.5 rounded-[var(--sa-r-sm)] px-1 py-1 transition-colors duration-[var(--sa-t-fast)]",
                  isActive ? "text-[var(--sa-text-hi)]" : "text-[var(--sa-text-dim)] hover:text-[var(--sa-text)]"
                )}
                style={isActive ? { color: it.accent } : undefined}
              >
                <span className="[&_svg]:h-[22px] [&_svg]:w-[22px]">
                  <IconCmp />
                </span>
                <span className="text-[10px] font-medium leading-none">{it.label}</span>
                <span
                  aria-hidden
                  className="mt-0.5 h-[2px] w-4 rounded-full transition-opacity"
                  style={{ background: it.accent, opacity: isActive ? 1 : 0 }}
                />
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
