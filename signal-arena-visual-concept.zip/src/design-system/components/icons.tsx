import type { ReactNode } from "react";

const S = ({ children }: { children: ReactNode }) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);

export const Icon = {
  hub: () => <S><path d="M3 12l9-8 9 8" /><path d="M5 10v10h14V10" /><path d="M9 20v-6h6v6" /></S>,
  academy: () => <S><path d="M3 7l9-4 9 4-9 4-9-4z" /><path d="M7 9v5c0 1 2 3 5 3s5-2 5-3V9" /></S>,
  arena: () => <S><path d="M12 2l2.4 6.6L21 9l-5 4.2L17.5 21 12 17l-5.5 4L8 13.2 3 9l6.6-.4z" /></S>,
  shop: () => <S><path d="M4 8h16l-1 12H5L4 8z" /><path d="M8 8a4 4 0 0 1 8 0" /></S>,
  tournament: () => <S><path d="M6 4h12v4a6 6 0 0 1-12 0V4z" /><path d="M6 6H3v2a3 3 0 0 0 3 3M18 6h3v2a3 3 0 0 1-3 3M9 18h6M8 22h8M10 18v-3M14 18v-3" /></S>,
  gear: () => <S><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3 1a7 7 0 0 0-2-1.2L16.2 2h-4l-.4 2.5a7 7 0 0 0-2 1.2l-2.3-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-1a7 7 0 0 0 2 1.2l.4 2.5h4l.4-2.5a7 7 0 0 0 2-1.2l2.3 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z" /></S>,
  bell: () => <S><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0" /></S>,
  bolt: () => <S><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z" /></S>,
  star: () => <S><path d="M12 2l3 6.5 7 .6-5.3 4.6L18.4 21 12 17.3 5.6 21l1.7-7.3L2 9.1l7-.6L12 2z" /></S>,
  coin: () => <S><circle cx="12" cy="12" r="9" /><path d="M12 7v10M9.5 9.5c0-1 1-1.5 2.5-1.5s2.5.7 2.5 1.7-1 1.3-2.5 1.3-2.5.5-2.5 1.5 1 1.5 2.5 1.5 2.5-.5 2.5-1.5" /></S>,
  lock: () => <S><rect x="4" y="10" width="16" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></S>,
  chevron: () => <S><path d="M9 6l6 6-6 6" /></S>,
  back: () => <S><path d="M15 6l-6 6 6 6" /></S>,
  seal: () => <S><circle cx="12" cy="10" r="6" /><path d="M9 15l-1 6 4-2 4 2-1-6" /></S>,
  eye: () => <S><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></S>,
  target: () => <S><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></S>,
  brain: () => <S><path d="M9 3a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 1 4 3 3 0 0 0 4 3 3 3 0 0 0 3-1V4a3 3 0 0 0-3-1z" /><path d="M15 3a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-1 4 3 3 0 0 1-4 3 3 3 0 0 1-3-1" /></S>,
  check: () => <S><path d="M20 6L9 17l-5-5" /></S>,
  x: () => <S><path d="M18 6L6 18M6 6l12 12" /></S>,
  layers: () => <S><path d="M12 2l9 5-9 5-9-5 9-5z" /><path d="M3 12l9 5 9-5M3 17l9 5 9-5" /></S>,
  filter: () => <S><path d="M3 5h18l-7 8v6l-4-2v-4L3 5z" /></S>,
  flame: () => <S><path d="M12 2s5 4 5 9a5 5 0 0 1-10 0c0-2 1-3 1-3s0 2 2 2c0-3 2-5 2-8z" /></S>,
  scale: () => <S><path d="M12 3v18M6 21h12" /><path d="M4 8l4-4 4 4M12 8l4-4 4 4" /></S>,
};

export type IconName = keyof typeof Icon;
