import { cn } from "../../utils/cn";

/*
 * MarketWorkspaceSlot — RESERVED, NEUTRAL placeholder for the future
 * isolated terminal/chart task. Intentionally contains NO candles,
 * indicators, order book, trade form, entry/stop/target lines, or
 * plausible market data. Outer size may be adapted at layout level only.
 */
export function MarketWorkspaceSlot({
  className,
  height = 220,
  caption = "Market workspace",
}: {
  className?: string;
  height?: number;
  caption?: string;
}) {
  return (
    <div
      className={cn(
        "relative w-full overflow-hidden rounded-[var(--sa-r-lg)] border border-dashed border-[var(--sa-line)] bg-[var(--sa-bg-1)]",
        className
      )}
      style={{ height }}
      role="img"
      aria-label="Reserved market workspace — visual placeholder, no live data"
    >
      {/* faint forensic grid only — deliberately abstract */}
      <div
        aria-hidden
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "linear-gradient(var(--sa-line-soft) 1px, transparent 1px), linear-gradient(90deg, var(--sa-line-soft) 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />
      <div className="relative flex h-full flex-col items-center justify-center gap-2 px-6 text-center">
        <div className="flex h-11 w-11 items-center justify-center rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] text-[var(--sa-text-dim)]">
          {/* neutral crosshair glyph, not a chart */}
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
            <circle cx="12" cy="12" r="7" />
            <path d="M12 2v4M12 18v4M2 12h4M18 12h4" strokeLinecap="round" />
          </svg>
        </div>
        <p className="sa-mono text-[11px] uppercase tracking-[0.18em] text-[var(--sa-text-dim)]">
          {caption}
        </p>
        <p className="max-w-[240px] text-[11px] leading-snug text-[var(--sa-text-faint)]">
          Reserved slot. The analytical terminal is built as an isolated task.
        </p>
      </div>
    </div>
  );
}
