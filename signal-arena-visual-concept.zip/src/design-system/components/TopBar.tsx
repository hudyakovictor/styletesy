import { cn } from "../../utils/cn";
import { Icon } from "./icons";
import type { ReactNode } from "react";

export function TopBar({
  title,
  onBack,
  right,
  subtitle,
  onProfile,
  onSettings,
  onBell,
  notifCount,
  avatar,
}: {
  title?: ReactNode;
  subtitle?: string;
  onBack?: () => void;
  right?: ReactNode;
  onProfile?: () => void;
  onSettings?: () => void;
  onBell?: () => void;
  notifCount?: number;
  avatar?: string;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--sa-line)] bg-[var(--sa-bg-0)]/85 backdrop-blur-md">
      <div className="flex h-14 items-center gap-2 px-3">
        {onBack ? (
          <button
            onClick={onBack}
            aria-label="Back"
            className="flex h-10 w-10 items-center justify-center rounded-full text-[var(--sa-text)] hover:bg-[var(--sa-bg-2)]"
          >
            <Icon.back />
          </button>
        ) : (
          <div className="flex items-center gap-2 pl-1">
            <SignalMark />
          </div>
        )}

        <div className="min-w-0 flex-1">
          {title && (
            <div className="sa-display truncate text-[15px] font-semibold text-[var(--sa-text-hi)]">
              {title}
            </div>
          )}
          {subtitle && (
            <div className="sa-mono truncate text-[10px] uppercase tracking-[0.16em] text-[var(--sa-text-dim)]">
              {subtitle}
            </div>
          )}
        </div>

        {right}

        <div className="flex items-center gap-0.5">
          {onBell && (
            <button
              onClick={onBell}
              aria-label="Notifications"
              className="relative flex h-10 w-10 items-center justify-center rounded-full text-[var(--sa-text)] hover:bg-[var(--sa-bg-2)]"
            >
              <Icon.bell />
              {!!notifCount && (
                <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--sa-danger)] px-1 text-[10px] font-bold text-white">
                  {notifCount}
                </span>
              )}
            </button>
          )}
          {onSettings && (
            <button
              onClick={onSettings}
              aria-label="Settings"
              className="flex h-10 w-10 items-center justify-center rounded-full text-[var(--sa-text)] hover:bg-[var(--sa-bg-2)]"
            >
              <Icon.gear />
            </button>
          )}
          {onProfile && (
            <button
              onClick={onProfile}
              aria-label="Open profile"
              className="ml-0.5 flex h-9 w-9 items-center justify-center overflow-hidden rounded-full border border-[var(--sa-line)] bg-[var(--sa-bg-3)] text-[13px] font-bold text-[var(--sa-signal)]"
            >
              {avatar ?? "SA"}
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

export function SignalMark({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="relative flex h-8 w-8 items-center justify-center rounded-[var(--sa-r-sm)] border border-[var(--sa-signal-dim)] bg-[var(--sa-bg-2)]">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--sa-signal)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 17l5-6 4 3 5-8 4 5" />
        </svg>
      </div>
      <div className="leading-none">
        <div className="sa-display text-[13px] font-bold text-[var(--sa-text-hi)]">SIGNAL</div>
        <div className="sa-mono text-[9px] tracking-[0.3em] text-[var(--sa-signal)]">ARENA</div>
      </div>
    </div>
  );
}
