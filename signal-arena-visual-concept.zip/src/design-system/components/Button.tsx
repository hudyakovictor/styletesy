import { cn } from "../../utils/cn";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "signal" | "ghost" | "outline" | "danger" | "locked";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  fullWidth?: boolean;
}

const base =
  "inline-flex items-center justify-center gap-2 font-medium select-none transition-colors duration-[var(--sa-t-base)] focus-visible:outline-2 disabled:opacity-45 disabled:cursor-not-allowed";

const sizes: Record<Size, string> = {
  sm: "min-h-[36px] px-3 text-[13px] rounded-[var(--sa-r-sm)]",
  md: "min-h-[44px] px-4 text-sm rounded-[var(--sa-r-md)]",
  lg: "min-h-[52px] px-5 text-[15px] rounded-[var(--sa-r-md)]",
};

const variants: Record<Variant, string> = {
  primary:
    "bg-[var(--sa-bg-3)] text-[var(--sa-text-hi)] border border-[var(--sa-line)] hover:bg-[var(--sa-bg-2)]",
  signal:
    "bg-[var(--sa-signal)] text-[#04140b] font-semibold hover:brightness-110 shadow-[var(--sa-glow-signal)]",
  ghost:
    "bg-transparent text-[var(--sa-text)] hover:text-[var(--sa-text-hi)] hover:bg-[var(--sa-bg-2)]",
  outline:
    "bg-transparent text-[var(--sa-text-hi)] border border-[var(--sa-line)] hover:border-[var(--sa-signal)] hover:text-[var(--sa-signal)]",
  danger:
    "bg-transparent text-[var(--sa-danger)] border border-[var(--sa-danger-dim)] hover:bg-[var(--sa-danger-dim)]/20",
  locked:
    "bg-[var(--sa-bg-2)] text-[var(--sa-text-dim)] border border-[var(--sa-line)] cursor-not-allowed",
};

export function Button({
  variant = "primary",
  size = "md",
  icon,
  fullWidth,
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(base, sizes[size], variants[variant], fullWidth && "w-full", className)}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
}
