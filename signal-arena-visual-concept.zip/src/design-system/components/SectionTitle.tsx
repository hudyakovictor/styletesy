import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

export function SectionTitle({
  children,
  action,
  kicker,
  className,
}: {
  children: ReactNode;
  action?: ReactNode;
  kicker?: string;
  className?: string;
}) {
  return (
    <div className={cn("mb-3 flex items-end justify-between gap-3", className)}>
      <div>
        {kicker && (
          <div className="sa-mono mb-0.5 text-[10px] uppercase tracking-[0.22em] text-[var(--sa-text-dim)]">
            {kicker}
          </div>
        )}
        <h2 className="sa-display text-[17px] font-semibold leading-tight text-[var(--sa-text-hi)]">
          {children}
        </h2>
      </div>
      {action}
    </div>
  );
}

export function Kicker({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span
      className="sa-mono text-[10px] uppercase tracking-[0.22em]"
      style={{ color: color ?? "var(--sa-text-dim)" }}
    >
      {children}
    </span>
  );
}
