import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

/* Scrollable content region for a screen. Shell handles safe spacing. */
export function ScreenShell({
  children,
  className,
  grid,
}: {
  children: ReactNode;
  className?: string;
  grid?: boolean;
}) {
  return (
    <main
      className={cn(
        "relative min-h-0 flex-1 overflow-y-auto overflow-x-hidden",
        grid && "sa-grid-bg",
        className
      )}
    >
      <div className="mx-auto w-full max-w-[520px] px-4 pb-6 pt-4">{children}</div>
    </main>
  );
}
