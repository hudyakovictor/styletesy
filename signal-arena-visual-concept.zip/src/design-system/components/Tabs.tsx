import { cn } from "../../utils/cn";

export interface TabItem {
  id: string;
  label: string;
}

export function Tabs({
  items,
  active,
  onChange,
  className,
}: {
  items: TabItem[];
  active: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div
      role="tablist"
      className={cn(
        "flex gap-1 overflow-x-auto rounded-[var(--sa-r-md)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] p-1",
        className
      )}
    >
      {items.map((t) => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(t.id)}
            className={cn(
              "min-h-[36px] flex-1 whitespace-nowrap rounded-[var(--sa-r-sm)] px-3 text-[13px] font-medium transition-colors duration-[var(--sa-t-fast)]",
              isActive
                ? "bg-[var(--sa-bg-3)] text-[var(--sa-text-hi)]"
                : "text-[var(--sa-text-dim)] hover:text-[var(--sa-text)]"
            )}
          >
            {t.label}
          </button>
        );
      })}
    </div>
  );
}
