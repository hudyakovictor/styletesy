import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

type Tone = "signal" | "noise" | "danger" | "neutral" | "info" | "locked";

const tones: Record<Tone, string> = {
  signal: "text-[var(--sa-signal)] border-[var(--sa-signal-dim)] bg-[var(--sa-signal)]/8",
  noise: "text-[var(--sa-noise)] border-[var(--sa-noise-dim)] bg-[var(--sa-noise)]/8",
  danger: "text-[var(--sa-danger)] border-[var(--sa-danger-dim)] bg-[var(--sa-danger)]/8",
  neutral: "text-[var(--sa-text)] border-[var(--sa-line)] bg-[var(--sa-bg-2)]",
  info: "text-[var(--sa-accent-academy)] border-[var(--sa-accent-academy)]/40 bg-[var(--sa-accent-academy)]/8",
  locked: "text-[var(--sa-text-dim)] border-[var(--sa-line)] bg-[var(--sa-bg-2)]",
};

export function Badge({
  tone = "neutral",
  children,
  className,
  icon,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
  icon?: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide sa-mono",
        tones[tone],
        className
      )}
    >
      {icon}
      {children}
    </span>
  );
}
