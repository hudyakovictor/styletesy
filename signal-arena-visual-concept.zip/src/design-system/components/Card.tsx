import { cn } from "../../utils/cn";
import type { HTMLAttributes, ReactNode } from "react";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  accent?: string;
  interactive?: boolean;
  glow?: boolean;
  as?: "div" | "button";
}

export function Card({
  accent,
  interactive,
  glow,
  className,
  children,
  style,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        "relative rounded-[var(--sa-r-lg)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)]",
        "shadow-[var(--sa-shadow-card)]",
        interactive &&
          "cursor-pointer transition-[transform,border-color] duration-[var(--sa-t-base)] hover:border-[var(--sa-line)]/80 hover:-translate-y-0.5",
        glow && "shadow-[var(--sa-glow-signal)]",
        className
      )}
      style={{
        ...(accent ? ({ ["--card-accent" as string]: accent } as Record<string, string>) : {}),
        ...style,
      }}
      {...props}
    >
      {accent && (
        <span
          aria-hidden
          className="absolute left-0 top-3 bottom-3 w-[3px] rounded-full"
          style={{ background: accent }}
        />
      )}
      {children}
    </div>
  );
}

export function CardBody({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("p-4", className)}>{children}</div>;
}
