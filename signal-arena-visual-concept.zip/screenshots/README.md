# Screenshots — capture guide

Screenshot capture requires an interactive browser, which was not available in the build
environment. Run `npm run build && npm run preview` (or `npm run dev`), open the app, and
capture each state below at the given viewport.

Mobile viewport: **390 × 844**. Desktop: **1440 × 900**.

| File | How to reach the state |
|------|------------------------|
| `00-entry-calibration-mobile.png` | First load → Entry screen, then tap "Start calibration". |
| `01-hub-mobile.png` | Enter app → Hub (default section). |
| `02-academy-mobile.png` | Bottom nav → Academy. |
| `02a-academy-collection-mobile.png` | Academy → "Open Vault" (nested Collection). |
| `03-arena-home-mobile.png` | Bottom nav → Arena (mode selection). |
| `03a-arena-scenario-brief-mobile.png` | Arena → Daily Case "Enter" → Scenario Brief. |
| `03b-arena-decision-workspace-mobile.png` | Brief → "Open Decision Workspace". |
| `03c-arena-reveal-score-debrief-mobile.png` | Workspace → "Seal decision" → "Seal & reveal". |
| `03d-arena-rematch-mobile.png` | Reveal → "Continue to rematch". |
| `04-shop-mobile.png` | Bottom nav → Shop. |
| `05-tournaments-mobile.png` | Bottom nav → Tournaments. |
| `secondary-profile-mobile.png` | Tap avatar in Top Bar → Profile drawer. |
| `secondary-settings-mobile.png` | Tap gear in Top Bar → Settings drawer. |
| `desktop-overview.png` | Any section at 1440×900 (Hub recommended). |

The five root sections in the bottom nav are exactly: Hub, Academy, Arena, Shop, Tournaments.
Arena states (03a–03d) are nested inside Arena, not separate menu items.
