# Signal Arena — Design Decisions

## Visual concept: "Forensic Terminal / Signal vs Noise"

Signal Arena is framed as an **investigation board**, not a trading terminal. The player is
an analyst doing forensics on decisions — separating real information (signal) from loud
nothing (noise). This drives every visual choice.

### Language
- **Surface**: deep graphite-blue (`--sa-bg-0` … `--sa-bg-3`) with a faint millimeter grid
  (`.sa-grid-bg`) that reads as an analyst's worksheet rather than a chart background.
- **Semantic core pair**: `--sa-signal` (cold acid green) vs `--sa-noise` (muted amber),
  with `--sa-danger` reserved for "likely noise / wrong". These are the spine of the product.
- **Typography**: Space Grotesk for display, JetBrains Mono for data/protocol lines and
  labels, Inter for body. The mono/label mix creates the "dry protocol" tone.
- **Sectional accents** (one system, not separate kits): Hub cyan, Academy blue, Arena
  signal-green, Shop amber, Tournaments violet+locked. Accents appear as a 3px card rail and
  in nav highlights only.

### Why not the anti-patterns
- Not a **Binance clone**: the market area is a *reserved neutral slot* with no candles,
  order book, or trade form.
- Not a **SaaS dashboard**: content is narrative case-files and evidence, not KPI widgets.
- Not **cyberpunk overload**: one restrained accent per section, single reveal animation.
- Not a **card battler / casino**: cards are analytical tools; Entities are observable
  distortions you *notice*, never monsters you attack. No coin showers or pulsing.

## Information architecture (fixed)
Exactly five root sections in the bottom nav: **Hub, Academy, Arena, Shop, Tournaments**.

Secondary surfaces are reached through their correct parent, never the main menu:
- **Entry / Calibration** — shown before the app shell (`booted` gate).
- **Profile** — avatar control in Top Bar (right drawer).
- **Settings** — single gear in Top Bar (right drawer).
- **Notifications** — bell in Top Bar (right drawer).
- **Collection / Vault** — nested *inside Academy* as a sub-catalog of Skill Cards + Entities.
  Also reachable as a secondary link from Profile loadout.

## Arena as the full practice loop
Arena owns the entire hands-on scenario as **nested states**, not root sections:

`home → brief → workspace → seal → reveal → score → debrief → rematch → back to Arena`

- Decision Seal is a confirmation modal inside the Workspace.
- Reveal + Score + Debrief are one screen (`reveal` state) to keep the payoff cohesive.
- The Top Bar back button walks the loop backward; Rematch returns to Arena home.

## Decision Workspace
The complex terminal is intentionally excluded. `MarketWorkspaceSlot` is a **read-only
neutral placeholder** (crosshair glyph + faint grid, no market data). All *surrounding*
environment is designed: evidence weighting, analytical tools (choose ≤3), hypothesis
commitment, confidence calibration, and the Seal CTA. Confidence copy explicitly warns that
overconfidence is penalized even on a correct outcome — reinforcing process-first learning.

## Data consistency
`content-library/mock-data.json` is the single source of truth. Level 7, Energy 4/6,
Stars 58, Coins 1240, current lesson "Signal vs Noise · 03", and Process Score 71 stay
identical across Hub, Academy, Arena, Profile.

## Motion
Only state-change motion. Single `sa-reveal` keyframe (400ms) for reveal/sheet entry;
transitions at 120/180/240ms. `prefers-reduced-motion` collapses all durations to ~0.

## Voice
Short and concrete, dry protocol mixed with light crypto-tabloid satire ("loud nothing",
"The hard truth"). The recurring thesis: **a good outcome does not prove a good process.**
