# Design System Gaps

> Note on baseline: the described baseline (`AGENT_START_HERE.md`, `docs/`,
> `content-library/*.json`, `included-assets.json`, and a pre-built `src/design-system/**`)
> was **not present** in the delivered project — only a bare React+Vite+Tailwind scaffold.
> To honor the task, a lightweight design system was authored under `src/design-system/**`
> (tokens + primitives). From creation onward it is treated as **read-only** by screen code:
> screens only import and compose it. No tokens are mutated from `src/concept/**`.

The following gaps were found while composing screens. Per instructions, these are recorded
here rather than solved by expanding the core unilaterally.

## 1. No dedicated Slider / RangeInput primitive
Confidence calibration uses a native `<input type="range">` styled with `accent-color`.
A tokenized `Slider` with labeled ticks and a value bubble would improve consistency and
touch ergonomics.

## 2. No Stepper / ProcessTracker primitive
The Arena loop (brief → workspace → reveal → rematch) and the Workspace's numbered steps use
local ad-hoc markup. A shared `Stepper` would standardize progress affordances.

## 3. No RadioGroup / SegmentedChoice primitive
Hypothesis selection and rarity filters are hand-rolled buttons with `aria-pressed`. A
tokenized single-select group would centralize keyboard semantics and selected styling.

## 4. No Toast / inline feedback
Demonstration actions (e.g. Shop "Preview", Settings toggles) have no confirmation surface.
A `Toast` primitive would be useful even in a concept.

## 5. No Avatar primitive
Profile/TopBar avatars are inline initials blocks. An `Avatar` (with fallback + size scale)
would remove duplication.

## 6. Rarity/quality color mapping lives in data + a helper
`rarityColor` is a screen-level map. A tokenized rarity scale exists in CSS
(`--sa-rare-*`); a typed accessor in the design system would prevent drift.

## 7. MarketWorkspaceSlot sizing contract
The slot accepts a `height` prop only. A future isolated terminal task will need a defined
content/interaction contract (safe insets, focus handoff) — out of scope here by design.
